package com.shimulfp.hub2stream.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.shimulfp.hub2stream.data.ContinueWatchingRepository
import com.shimulfp.hub2stream.data.LiveTVRepository
import com.shimulfp.hub2stream.data.MovieRepository
import com.shimulfp.hub2stream.data.SportsRepository
import com.shimulfp.hub2stream.extractor.models.HomePageRow
import com.shimulfp.hub2stream.extractor.models.LiveChannel
import com.shimulfp.hub2stream.extractor.models.SportsEvent
import com.shimulfp.hub2stream.models.ContinueWatchingItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

data class HomeUiState(
    val movieRows: List<HomePageRow> = emptyList(),
    val liveChannels: List<LiveChannel> = emptyList(),
    val liveEvents: List<SportsEvent> = emptyList(),
    val isLoadingMovies: Boolean = true,
    val isLoadingLiveTV: Boolean = true,
    val isLoadingSports: Boolean = true,
    val continueWatchingItems: List<ContinueWatchingItem> = emptyList()
)

class HomeViewModel(application: Application) : AndroidViewModel(application) {
    private val movieRepo = MovieRepository(application)
    private val liveTvRepo = LiveTVRepository()
    private val sportsRepo = SportsRepository()
    private val continueWatchingRepo = ContinueWatchingRepository(application)

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState

    init {
        // Observe continue watching items continuously
        viewModelScope.launch {
            continueWatchingRepo.items
                .catch { e -> e.printStackTrace() }
                .collect { items ->
                    _uiState.value = _uiState.value.copy(continueWatchingItems = items)
                }
        }
        loadHomeData()
    }

    fun loadHomeData() {
        viewModelScope.launch {
            // Movies
            launch {
                val result = withTimeoutOrNull(60000L) { movieRepo.getHomePageRows() } ?: emptyList()
                _uiState.value = _uiState.value.copy(
                    movieRows = result,
                    isLoadingMovies = false
                )
            }
            // Live TV
            launch {
                val result = withTimeoutOrNull(60000L) { liveTvRepo.getChannels() } ?: emptyList()
                _uiState.value = _uiState.value.copy(
                    liveChannels = result,
                    isLoadingLiveTV = false
                )
            }
            // Live Sports
            launch {
                val result = withTimeoutOrNull(15000L) { sportsRepo.getLiveEvents() } ?: emptyList()
                _uiState.value = _uiState.value.copy(
                    liveEvents = result,
                    isLoadingSports = false
                )
            }
        }
    }
}