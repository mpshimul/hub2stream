package com.shimulfp.hub2stream.data

import com.shimulfp.hub2stream.extractor.LiveTVExtractor
import com.shimulfp.hub2stream.extractor.RoarZoneExtractor
import com.shimulfp.hub2stream.extractor.models.LiveChannel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

class LiveTVRepository {
    private val redForceExtractor = LiveTVExtractor()
    private val roarZoneExtractor = RoarZoneExtractor()

    companion object {
        private var cachedChannels: List<LiveChannel>? = null
        private var cacheTimestamp: Long = 0
        private const val CACHE_TTL_MS = 30 * 60 * 1000L // 30 minutes
    }

    suspend fun getChannels(): List<LiveChannel> = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()

        // Return cache if still fresh
        if (cachedChannels != null && (now - cacheTimestamp) < CACHE_TTL_MS) {
            println("LiveTV: using cached channels (${cachedChannels!!.size} channels)")
            return@withContext cachedChannels!!
        }

        // Try RedForce first (primary source)
        val redForceChannels = try {
            withTimeoutOrNull(10000L) { redForceExtractor.fetchChannels() } ?: emptyList()
        } catch (e: Exception) { emptyList() }
        if (redForceChannels.isNotEmpty()) {
            println("LiveTV: fetched ${redForceChannels.size} fresh channels from RedForce")
            cachedChannels = redForceChannels
            cacheTimestamp = now
            return@withContext redForceChannels
        }

        // Fallback to RoarZone
        val roarZoneChannels = try {
            withTimeoutOrNull(60000L) { roarZoneExtractor.fetchChannels() } ?: emptyList()
        } catch (e: Exception) { emptyList() }
        if (roarZoneChannels.isNotEmpty()) {
            println("LiveTV: fetched ${roarZoneChannels.size} fresh channels from RoarZone (fallback)")
            cachedChannels = roarZoneChannels
            cacheTimestamp = now
            return@withContext roarZoneChannels
        }

        println("LiveTV: No channels from any source")
        emptyList()
    }

    suspend fun refreshChannels(): List<LiveChannel> {
        cachedChannels = null
        cacheTimestamp = 0
        return getChannels()
    }
}