// ContinueWatchingItem.kt
package com.shimulfp.hub2stream.models

import kotlinx.serialization.Serializable

@Serializable
data class ContinueWatchingItem(
    val contentId: String,
    val slug: String,
    val title: String,
    val posterUrl: String,
    val type: String,
    val seasonNumber: Int = 0,
    val episodeNumber: Int = 0,
    val episodeTitle: String = "",
    val positionSeconds: Long,
    val durationSeconds: Long,
    val timestamp: Long = System.currentTimeMillis()
)