package com.shimulfp.hub2stream.ui.screens

import android.app.Activity
import android.app.Application
import android.content.pm.ActivityInfo
import android.net.Uri
import android.util.Log
import android.view.KeyEvent as AndroidKeyEvent
import android.view.View
import android.view.WindowManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.nativeKeyCode
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.zIndex
import androidx.navigation.NavController
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.fasterxml.jackson.module.kotlin.readValue
import com.shimulfp.hub2stream.data.MovieRepository
import com.shimulfp.hub2stream.data.ContinueWatchingRepository
import com.shimulfp.hub2stream.extractor.models.QualityInfo
import com.shimulfp.hub2stream.extractor.models.SubtitleInfo
import com.shimulfp.hub2stream.models.ContinueWatchingItem
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.net.URLDecoder

private const val TAG = "PlayerScreen"

data class EpisodeItem(val url: String, val title: String)
data class TrackInfo(val trackGroupIndex: Int, val trackIndex: Int, val label: String, val language: String? = null)

@OptIn(UnstableApi::class, ExperimentalComposeUiApi::class)
@Composable
fun PlayerScreen(
    navController: NavController,
    url: String,
    title: String,
    episodesJson: String,
    startIndex: Int,
    isLive: Boolean,
    slug: String = "",
    poster: String = "",
    type: String = "",
    season: Int = 0,
    episode: Int = 0,
    resumePosition: Long = 0L
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val scope = rememberCoroutineScope()
    val application = context.applicationContext as Application
    val continueWatchingRepo = remember { ContinueWatchingRepository(application) }
    val movieRepo = remember { MovieRepository(application) }

    // State
    var availableQualities by remember { mutableStateOf<List<QualityInfo>>(emptyList()) }
    var currentStreamUrl by remember { mutableStateOf("") }
    var currentStreamId by remember { mutableStateOf("") }
    var isLoadingStream by remember { mutableStateOf(true) }
    var streamError by remember { mutableStateOf<String?>(null) }
    var subtitleList by remember { mutableStateOf<List<SubtitleInfo>>(emptyList()) }
    var subjectId by remember { mutableStateOf("") }
    var detailPath by remember { mutableStateOf("") }
    var isBuffering by remember { mutableStateOf(false) }

    // UI dialogs
    var showQualityDialog by remember { mutableStateOf(false) }
    var showAudioDialog by remember { mutableStateOf(false) }
    var showSubtitleDialog by remember { mutableStateOf(false) }
    var audioTracks by remember { mutableStateOf<List<TrackInfo>>(emptyList()) }
    var subtitleTracks by remember { mutableStateOf<List<TrackInfo>>(emptyList()) }
    var selectedAudioTrack by remember { mutableStateOf<TrackInfo?>(null) }
    var selectedSubtitleTrack by remember { mutableStateOf<TrackInfo?>(null) }

    // Parse episodes
    val episodes = remember(episodesJson) {
        if (episodesJson.isNotBlank()) {
            try {
                val decoded = URLDecoder.decode(episodesJson, "UTF-8")
                val mapper = jacksonObjectMapper()
                val list: List<Map<String, String>> = mapper.readValue(decoded)
                list.map { EpisodeItem(it["url"] ?: "", it["title"] ?: "") }
            } catch (e: Exception) { emptyList() }
        } else emptyList()
    }

    var currentIndex by remember { mutableStateOf(startIndex) }
    var currentTitle by remember(title) { mutableStateOf(title) }
    var isControlsVisible by remember { mutableStateOf(true) }
    var hideJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }
    var showChannelInfo by remember { mutableStateOf(false) }
    var channelInfoText by remember { mutableStateOf("") }
    var exoPlayerState by remember { mutableStateOf<ExoPlayer?>(null) }
    var trackSelectorState by remember { mutableStateOf<DefaultTrackSelector?>(null) }
    var playerViewState by remember { mutableStateOf<PlayerView?>(null) }
    var currentPosition by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var isPlaying by remember { mutableStateOf(true) }
    var currentScaleMode by remember { mutableIntStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }
    val scaleModes = listOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT to "Fit",
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM to "Zoom",
        AspectRatioFrameLayout.RESIZE_MODE_FILL to "Fill",
        AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH to "Fixed Width",
        AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT to "Fixed Height"
    )

    // ---------- Helper functions ----------
    fun resetAutoHideTimer() {
        hideJob?.cancel()
        hideJob = scope.launch {
            delay(5000)
            isControlsVisible = false
        }
    }

    fun showControlsTemporarily() {
        hideJob?.cancel()
        isControlsVisible = true
        resetAutoHideTimer()
    }

    fun showChannelInfoTemporarily(text: String) {
        channelInfoText = text
        showChannelInfo = true
        scope.launch {
            delay(2000)
            showChannelInfo = false
        }
        resetAutoHideTimer()
    }

    fun formatTime(ms: Long): String {
        if (ms <= 0) return "00:00"
        val totalSeconds = ms / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) String.format("%02d:%02d:%02d", hours, minutes, seconds)
        else String.format("%02d:%02d", minutes, seconds)
    }

    fun cycleScaleMode() {
        val currentIdx = scaleModes.indexOfFirst { it.first == currentScaleMode }
        val nextIdx = (currentIdx + 1) % scaleModes.size
        currentScaleMode = scaleModes[nextIdx].first
        playerViewState?.resizeMode = currentScaleMode
        showChannelInfoTemporarily("Scale: ${scaleModes[nextIdx].second}")
    }
    // ---------- End helpers ----------

    // Fetch streams and subtitles once
    LaunchedEffect(Unit) {
        if (url.startsWith("moviebox://")) {
            val linkData = url.removePrefix("moviebox://")
            val parts = linkData.split("|")
            subjectId = parts.getOrNull(0) ?: ""
            detailPath = parts.getOrNull(3) ?: ""
            Log.d(TAG, "Fetching streams for subjectId=$subjectId, detailPath=$detailPath")
            movieRepo.getStreams(linkData) { qualities, _ ->
                if (qualities.isNotEmpty()) {
                    availableQualities = qualities
                    val best = qualities.maxByOrNull { it.resolution } ?: qualities.first()
                    currentStreamUrl = best.url
                    currentStreamId = best.id
                    Log.d(TAG, "Available qualities: ${qualities.map { it.label }}")
                    Log.d(TAG, "Selected quality: ${best.label}")
                    scope.launch {
                        val subs = movieRepo.fetchSubtitles(subjectId, best.id, detailPath)
                        subtitleList = subs
                        Log.d(TAG, "Fetched ${subs.size} subtitles: ${subs.map { it.languageName }}")
                    }
                } else {
                    streamError = "No streams available"
                }
                isLoadingStream = false
            }
        } else {
            currentStreamUrl = url
            isLoadingStream = false
        }
    }

    // Build MediaItem with subtitles attached (using SELECTION_FLAG_DEFAULT for auto-selection)
    fun buildMediaItem(videoUrl: String, subtitles: List<SubtitleInfo>): MediaItem {
        val builder = MediaItem.Builder()
            .setUri(Uri.parse(videoUrl))
            .setCustomCacheKey(videoUrl)
        if (subtitles.isNotEmpty()) {
            val subtitleConfigs = subtitles.map { sub ->
                MediaItem.SubtitleConfiguration.Builder(Uri.parse(sub.url))
                    .setMimeType("application/x-subrip")
                    .setLanguage(sub.languageCode)
                    .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                    .build()
            }
            builder.setSubtitleConfigurations(subtitleConfigs)
            Log.d(TAG, "Added ${subtitleConfigs.size} subtitle tracks to MediaItem")
        }
        return builder.build()
    }

    // Quality selection (reuses subtitles, preserves position)
    fun selectQuality(quality: QualityInfo) {
        if (currentStreamUrl == quality.url) return
        val player = exoPlayerState ?: return
        val wasPlaying = player.isPlaying
        val currentPos = player.currentPosition

        currentStreamUrl = quality.url
        currentStreamId = quality.id

        val mediaItem = buildMediaItem(quality.url, subtitleList)
        player.setMediaItem(mediaItem)
        player.prepare()
        scope.launch {
            while (player.playbackState != Player.STATE_READY) {
                delay(50)
            }
            player.seekTo(currentPos)
            if (wasPlaying) player.play()
            showChannelInfoTemporarily("Quality: ${quality.label}")
            Log.d(TAG, "Switched to quality ${quality.label}, position=$currentPos")
        }
        showQualityDialog = false
    }

    // Headers and data source
    val headers = remember {
        mutableMapOf(
            "Referer" to "https://themoviebox.org/",
            "Origin" to "https://themoviebox.org",
            "User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        )
    }

    val dataSourceFactory = remember(headers) {
        DefaultHttpDataSource.Factory()
            .setDefaultRequestProperties(headers)
            .setUserAgent(headers["User-Agent"] ?: "ExoPlayer")
    }

    val loadControl = DefaultLoadControl.Builder()
        .setBufferDurationsMs(15000, 50000, 500, 500)
        .build()

    val exoPlayer = remember {
        val trackSelector = DefaultTrackSelector(context)
        ExoPlayer.Builder(context)
            .setTrackSelector(trackSelector)
            .setLoadControl(loadControl)
            .setMediaSourceFactory(DefaultMediaSourceFactory(context).setDataSourceFactory(dataSourceFactory))
            .build()
    }.also { exoPlayerState = it; trackSelectorState = it.trackSelector as DefaultTrackSelector }

    // Initial media load
    LaunchedEffect(currentStreamUrl, subtitleList) {
        if (currentStreamUrl.isNotBlank()) {
            val mediaItem = buildMediaItem(currentStreamUrl, subtitleList)
            exoPlayer.setMediaItem(mediaItem)
            exoPlayer.prepare()
            exoPlayer.playWhenReady = true
            exoPlayer.play()
        }
    }

    // Resume from saved position
    LaunchedEffect(exoPlayer, resumePosition) {
        if (resumePosition > 0 && !isLive) {
            while (exoPlayer.duration <= 0 && exoPlayer.playbackState != Player.STATE_READY) {
                delay(100)
            }
            if (exoPlayer.duration > 0 && resumePosition < exoPlayer.duration) {
                exoPlayer.seekTo(resumePosition)
                currentPosition = resumePosition
                Log.d(TAG, "Resumed at position $resumePosition ms")
            }
        }
    }

    // Extract audio/subtitle tracks for dialogs and force select English subtitle after player ready
    LaunchedEffect(exoPlayer) {
        while (true) {
            delay(500)
            if (exoPlayer.currentTracks.groups.isNotEmpty()) {
                val audioList = mutableListOf<TrackInfo>()
                val subList = mutableListOf<TrackInfo>()
                subList.add(TrackInfo(-1, -1, "Off", null))
                var audioGroupIdx = 0
                var textGroupIdx = 0
                exoPlayer.currentTracks.groups.forEach { group ->
                    when (group.type) {
                        C.TRACK_TYPE_AUDIO -> {
                            for (i in 0 until group.length) {
                                val format = group.getTrackFormat(i)
                                val label = format.label ?: format.language ?: "Audio $i"
                                audioList.add(TrackInfo(audioGroupIdx, i, label, format.language))
                            }
                            audioGroupIdx++
                        }
                        C.TRACK_TYPE_TEXT -> {
                            for (i in 0 until group.length) {
                                val format = group.getTrackFormat(i)
                                val label = format.label ?: format.language ?: "Subtitle $i"
                                subList.add(TrackInfo(textGroupIdx, i, label, format.language))
                                Log.d(TAG, "Found subtitle track: ${format.language} - $label")
                            }
                            textGroupIdx++
                        }
                    }
                }
                audioTracks = audioList
                subtitleTracks = subList
                selectedAudioTrack = audioList.firstOrNull()
                val englishTrack = subList.find { it.language == "en" || it.label.contains("English", ignoreCase = true) }
                selectedSubtitleTrack = englishTrack ?: subList.firstOrNull()
                Log.d(TAG, "Default subtitle track determined: ${selectedSubtitleTrack?.label}")

                // Force select English subtitle track after player is ready
                if (englishTrack != null && englishTrack.trackGroupIndex >= 0) {
                    // Wait for player to be ready
                    while (exoPlayer.playbackState != Player.STATE_READY) {
                        delay(100)
                    }
                    var idx = 0
                    exoPlayer.currentTracks.groups.forEach { group ->
                        if (group.type == C.TRACK_TYPE_TEXT) {
                            if (idx == englishTrack.trackGroupIndex) {
                                val override = TrackSelectionOverride(group.mediaTrackGroup, englishTrack.trackIndex)
                                trackSelectorState?.setParameters(trackSelectorState!!.buildUponParameters().setOverrideForType(override))
                                Log.d(TAG, "Force selected English subtitle track (group=$idx, track=${englishTrack.trackIndex})")
                            }
                            idx++
                        }
                    }
                }
                break
            }
        }
    }

    // Save progress periodically
    LaunchedEffect(exoPlayer, slug, type, season, episode, title, poster) {
        var lastSaved = 0L
        while (true) {
            delay(5000)
            if (!isLive && slug.isNotBlank() && exoPlayer.duration > 0) {
                val position = exoPlayer.currentPosition
                val dur = exoPlayer.duration
                if (kotlin.math.abs(position - lastSaved) > 5000 && position < dur - 5000) {
                    lastSaved = position
                    val item = ContinueWatchingItem(
                        contentId = if (type == "movie") slug else "${slug}_s${season}e${episode}",
                        slug = slug,
                        title = title,
                        posterUrl = poster,
                        type = type,
                        seasonNumber = season,
                        episodeNumber = episode,
                        episodeTitle = if (type == "series") title.substringAfter(" - ") else "",
                        positionSeconds = position / 1000,
                        durationSeconds = dur / 1000,
                        timestamp = System.currentTimeMillis()
                    )
                    continueWatchingRepo.addOrUpdateItem(item)
                }
            }
        }
    }

    // Update UI state
    LaunchedEffect(exoPlayer) {
        while (true) {
            delay(200)
            currentPosition = exoPlayer.currentPosition
            duration = exoPlayer.duration
            isPlaying = exoPlayer.isPlaying
        }
    }

    // Player event listener (buffering)
    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val newIndex = exoPlayer.currentMediaItemIndex
                if (episodes.isNotEmpty() && newIndex != currentIndex) {
                    currentIndex = newIndex
                    currentTitle = episodes.getOrNull(newIndex)?.title ?: ""
                }
                resetAutoHideTimer()
            }
            override fun onPlaybackStateChanged(state: Int) {
                isBuffering = (state == Player.STATE_BUFFERING)
                if (state == Player.STATE_READY) {
                    resetAutoHideTimer()
                    Log.d(TAG, "Player ready, duration=${exoPlayer.duration}ms")
                }
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    // Screen orientation & fullscreen
    DisposableEffect(Unit) {
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        activity?.window?.decorView?.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                )
        onDispose {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
            activity?.window?.decorView?.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        }
    }

    // Key handling
    fun handleKeyEvent(key: Key, type: KeyEventType): Boolean {
        if (type == KeyEventType.KeyDown) {
            resetAutoHideTimer()
            when (key.nativeKeyCode) {
                AndroidKeyEvent.KEYCODE_DPAD_CENTER, AndroidKeyEvent.KEYCODE_ENTER -> {
                    if (!isControlsVisible) showControlsTemporarily()
                    return true
                }
                AndroidKeyEvent.KEYCODE_DPAD_LEFT -> {
                    if (!isControlsVisible) {
                        exoPlayer.seekBack()
                        showChannelInfoTemporarily("Rewind")
                        return true
                    }
                    return false
                }
                AndroidKeyEvent.KEYCODE_DPAD_RIGHT -> {
                    if (!isControlsVisible) {
                        exoPlayer.seekForward()
                        showChannelInfoTemporarily("Forward")
                        return true
                    }
                    return false
                }
                AndroidKeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                    if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                    showControlsTemporarily()
                    return true
                }
                AndroidKeyEvent.KEYCODE_BACK, AndroidKeyEvent.KEYCODE_ESCAPE -> {
                    navController.popBackStack()
                    return true
                }
            }
        }
        return false
    }

    // Audio track selection
    fun selectAudioTrack(track: TrackInfo) {
        trackSelectorState?.let { selector ->
            var idx = 0
            exoPlayer.currentTracks.groups.forEach { group ->
                if (group.type == C.TRACK_TYPE_AUDIO) {
                    if (idx == track.trackGroupIndex) {
                        val override = TrackSelectionOverride(group.mediaTrackGroup, track.trackIndex)
                        selector.setParameters(selector.buildUponParameters().setOverrideForType(override))
                        selectedAudioTrack = track
                        showChannelInfoTemporarily("Audio: ${track.label}")
                        Log.d(TAG, "Audio track selected: ${track.label}")
                    }
                    idx++
                }
            }
        }
        showAudioDialog = false
    }

    // Subtitle track selection (user-triggered, safe)
    fun selectSubtitleTrack(track: TrackInfo) {
        trackSelectorState?.let { selector ->
            if (track.trackGroupIndex < 0) {
                selector.setParameters(selector.buildUponParameters().setDisabledTrackTypes(setOf(C.TRACK_TYPE_TEXT)))
                selectedSubtitleTrack = track
                showChannelInfoTemporarily("Subtitles off")
                Log.d(TAG, "Subtitles turned off")
            } else {
                var idx = 0
                exoPlayer.currentTracks.groups.forEach { group ->
                    if (group.type == C.TRACK_TYPE_TEXT) {
                        if (idx == track.trackGroupIndex) {
                            val override = TrackSelectionOverride(group.mediaTrackGroup, track.trackIndex)
                            selector.setParameters(selector.buildUponParameters().setOverrideForType(override))
                            selectedSubtitleTrack = track
                            showChannelInfoTemporarily("Subtitles: ${track.label}")
                            Log.d(TAG, "Subtitle track selected: ${track.label}")
                        }
                        idx++
                    }
                }
            }
        }
        showSubtitleDialog = false
    }

    // ---------- UI ----------
    Box(
        modifier = Modifier
            .fillMaxSize()
            .focusable()
            .onKeyEvent { handleKeyEvent(it.key, it.type) }
    ) {
        when {
            isLoadingStream -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
            streamError != null -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Error: $streamError", color = Color.White)
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(onClick = { navController.popBackStack() }) { Text("Back") }
                }
            }
            else -> {
                AndroidView(
                    factory = { ctx ->
                        PlayerView(ctx).apply {
                            player = exoPlayer
                            useController = false
                            keepScreenOn = true
                            setShowNextButton(false)
                            setShowPreviousButton(false)
                            resizeMode = currentScaleMode
                            setOnClickListener { showControlsTemporarily() }
                        }.also { playerViewState = it }
                    },
                    modifier = Modifier.fillMaxSize()
                )

                // Buffering overlay
                if (isBuffering) {
                    Box(
                        modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f)),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = Color.Yellow)
                    }
                }

                // Controls overlay
                AnimatedVisibility(
                    visible = isControlsVisible,
                    enter = fadeIn(),
                    exit = fadeOut(),
                    modifier = Modifier.fillMaxSize()
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        // Top bar
                        Surface(
                            modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding(),
                            color = Color.Black.copy(alpha = 0.7f)
                        ) {
                            Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { navController.popBackStack() }) {
                                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White)
                                }
                                Text(currentTitle, modifier = Modifier.weight(1f), color = Color.White, maxLines = 1)
                                if (!isLive) {
                                    if (availableQualities.size > 1) {
                                        IconButton(onClick = { showQualityDialog = true }) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                Icon(Icons.Filled.Hd, "Quality", tint = Color.White, modifier = Modifier.size(54.dp))
                                                Text("Quality", color = Color.White, fontSize = 10.sp)
                                            }
                                        }
                                    }
                                    IconButton(onClick = { showAudioDialog = true }) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Icon(Icons.Filled.VolumeUp, "Audio", tint = Color.White, modifier = Modifier.size(54.dp))
                                            Text("Audio", color = Color.White, fontSize = 10.sp)
                                        }
                                    }
                                    IconButton(onClick = { showSubtitleDialog = true }) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Icon(Icons.Filled.ClosedCaption, "Subtitle", tint = Color.White, modifier = Modifier.size(54.dp))
                                            Text("Subtitle", color = Color.White, fontSize = 10.sp)
                                        }
                                    }
                                    IconButton(onClick = { cycleScaleMode() }) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Icon(Icons.Filled.ZoomOutMap, "Scale", tint = Color.White, modifier = Modifier.size(54.dp))
                                            Text("Scale", color = Color.White, fontSize = 10.sp)
                                        }
                                    }
                                }
                            }
                        }

                        // Bottom bar
                        Surface(
                            modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(16.dp),
                            color = Color.Black.copy(alpha = 0.7f)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                if (!isLive) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(formatTime(currentPosition), color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(end = 8.dp))
                                        Slider(
                                            value = if (duration > 0) currentPosition.toFloat() / duration.toFloat() else 0f,
                                            onValueChange = { exoPlayer.seekTo((it * duration).toLong()) },
                                            modifier = Modifier.weight(1f),
                                            colors = SliderDefaults.colors(activeTrackColor = Color.Yellow, thumbColor = Color.Yellow)
                                        )
                                        Text(formatTime(duration), color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp))
                                    }
                                }
                                Row(horizontalArrangement = Arrangement.SpaceEvenly, modifier = Modifier.fillMaxWidth()) {
                                    IconButton(onClick = { exoPlayer.seekBack() }) { Icon(Icons.Filled.FastRewind, "Rewind", tint = Color.White) }
                                    IconButton(onClick = { if (isPlaying) exoPlayer.pause() else exoPlayer.play() }) {
                                        Icon(if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Play/Pause", tint = Color.White, modifier = Modifier.size(64.dp))
                                    }
                                    IconButton(onClick = { exoPlayer.seekForward() }) { Icon(Icons.Filled.FastForward, "Forward", tint = Color.White) }
                                }
                            }
                        }
                    }
                }

                // Quality dialog
                if (showQualityDialog) {
                    Dialog(onDismissRequest = { showQualityDialog = false }) {
                        Surface(modifier = Modifier.fillMaxWidth(0.5f), color = Color.Black.copy(alpha = 0.9f), shape = RoundedCornerShape(12.dp)) {
                            Column(Modifier.padding(16.dp)) {
                                Text("Select Quality", color = Color.White, fontWeight = FontWeight.Bold)
                                availableQualities.sortedByDescending { it.resolution }.forEach { quality ->
                                    val isSelected = currentStreamUrl == quality.url
                                    Row(
                                        modifier = Modifier.fillMaxWidth().clickable { selectQuality(quality) }.padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(quality.label, color = Color.White)
                                        if (isSelected) Icon(Icons.Filled.Check, null, tint = Color.Yellow)
                                    }
                                }
                            }
                        }
                    }
                }

                // Audio dialog
                if (showAudioDialog) {
                    Dialog(onDismissRequest = { showAudioDialog = false }) {
                        Surface(modifier = Modifier.fillMaxWidth(0.5f), color = Color.Black.copy(alpha = 0.9f), shape = RoundedCornerShape(12.dp)) {
                            Column(Modifier.padding(16.dp)) {
                                Text("Select Audio", color = Color.White, fontWeight = FontWeight.Bold)
                                audioTracks.forEach { track ->
                                    val isSelected = selectedAudioTrack?.trackGroupIndex == track.trackGroupIndex &&
                                            selectedAudioTrack?.trackIndex == track.trackIndex
                                    Row(
                                        modifier = Modifier.fillMaxWidth().clickable { selectAudioTrack(track) }.padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(track.label, color = Color.White)
                                        if (isSelected) Icon(Icons.Filled.Check, null, tint = Color.Yellow)
                                    }
                                }
                            }
                        }
                    }
                }

                // Subtitle dialog
                if (showSubtitleDialog) {
                    Dialog(onDismissRequest = { showSubtitleDialog = false }) {
                        Surface(modifier = Modifier.fillMaxWidth(0.5f), color = Color.Black.copy(alpha = 0.9f), shape = RoundedCornerShape(12.dp)) {
                            Column(Modifier.padding(16.dp)) {
                                Text("Select Subtitle", color = Color.White, fontWeight = FontWeight.Bold)
                                subtitleTracks.forEach { track ->
                                    val isSelected = selectedSubtitleTrack?.trackGroupIndex == track.trackGroupIndex &&
                                            selectedSubtitleTrack?.trackIndex == track.trackIndex
                                    Row(
                                        modifier = Modifier.fillMaxWidth().clickable { selectSubtitleTrack(track) }.padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(track.label, color = Color.White)
                                        if (isSelected) Icon(Icons.Filled.Check, null, tint = Color.Yellow)
                                    }
                                }
                            }
                        }
                    }
                }

                // Info overlay
                AnimatedVisibility(
                    visible = showChannelInfo,
                    enter = fadeIn(),
                    exit = fadeOut(),
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 180.dp)
                ) {
                    Surface(color = Color.Black.copy(alpha = 0.8f), shape = RoundedCornerShape(8.dp)) {
                        Text(channelInfoText, color = Color.White, modifier = Modifier.padding(16.dp))
                    }
                }
            }
        }
    }
}