package com.shimulfp.hub2stream.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.shimulfp.hub2stream.data.MovieRepository
import com.shimulfp.hub2stream.extractor.models.MediaItemPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class CategoryViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = MovieRepository(application)
    private val _items = MutableStateFlow<List<MediaItemPreview>>(emptyList())
    val items: StateFlow<List<MediaItemPreview>> = _items
    private val _isLoading = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    fun loadItems(slugs: List<String>) {
        viewModelScope.launch {
            _isLoading.value = true
            _error.value = null
            try {
                val items = slugs.mapNotNull { slug ->
                    val movie = repo.getMovieDetails(slug)
                    if (movie != null) {
                        MediaItemPreview.MoviePreview(movie.title, movie.posterUrl, slug)
                    } else {
                        val series = repo.getSeriesDetails(slug)
                        if (series != null) {
                            MediaItemPreview.SeriesPreview(series.title, series.posterUrl, slug)
                        } else null
                    }
                }
                _items.value = items
            } catch (e: Exception) {
                _error.value = e.message
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun loadSeriesByCategory(category: String? = null) {
        viewModelScope.launch {
            _isLoading.value = true
            _error.value = null
            try {
                val seriesList = repo.getAllSeriesByCategory(category)
                val previews = seriesList.map { series ->
                    MediaItemPreview.SeriesPreview(series.title, series.posterUrl, series.slug)
                }
                _items.value = previews
                if (previews.isEmpty()) {
                    _error.value = "No series found for this category."
                }
            } catch (e: Exception) {
                _error.value = e.message
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun setItems(newItems: List<MediaItemPreview>) {
        _items.value = newItems
        _isLoading.value = false
        _error.value = null
    }
}