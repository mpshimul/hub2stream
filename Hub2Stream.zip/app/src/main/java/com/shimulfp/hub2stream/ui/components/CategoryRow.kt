package com.shimulfp.hub2stream.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.unit.dp

@Composable
fun <T> CategoryRow(
    title: String,
    items: List<T>,
    onItemClick: (T) -> Unit,
    onMoreClick: () -> Unit,
    posterContent: @Composable (T, Boolean) -> Unit,  // requestFocus param
    isFirstRow: Boolean = false,
    rowFocusRequester: FocusRequester? = null
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
            TextButton(onClick = onMoreClick) {
                Text("More", color = MaterialTheme.colorScheme.primary)
                Icon(Icons.Default.ArrowForward, null, Modifier.size(16.dp))
            }
        }
        LazyRow(
            modifier = Modifier.then(if (rowFocusRequester != null) Modifier.focusRequester(rowFocusRequester) else Modifier),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            itemsIndexed(items) { index, item ->
                posterContent(item, isFirstRow && index == 0)  // first item of first row requests focus
            }
        }
    }
}