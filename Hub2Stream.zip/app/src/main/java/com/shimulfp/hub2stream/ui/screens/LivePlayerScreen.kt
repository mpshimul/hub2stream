package com.shimulfp.hub2stream.ui.screens

import android.app.Activity
import android.content.pm.ActivityInfo
import android.net.Uri
import android.view.KeyEvent as AndroidKeyEvent
import android.view.View
import android.view.WindowManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.ZoomOutMap
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.nativeKeyCode
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.zIndex
import androidx.navigation.NavController
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.fasterxml.jackson.module.kotlin.readValue
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.net.URLDecoder

data class LiveChannelItem(val url: String, val title: String)

@OptIn(UnstableApi::class, ExperimentalComposeUiApi::class)
@Composable
fun LivePlayerScreen(
    navController: NavController,
    url: String,
    title: String,
    channelsJson: String,
    startIndex: Int
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val scope = rememberCoroutineScope()

    // Parse channel list
    val channels = remember(channelsJson) {
        if (channelsJson.isNotBlank()) {
            try {
                val decoded = URLDecoder.decode(channelsJson, "UTF-8")
                val mapper = jacksonObjectMapper()
                val list: List<Map<String, String>> = mapper.readValue(decoded)
                list.map { LiveChannelItem(it["url"] ?: "", it["title"] ?: "") }
            } catch (e: Exception) { emptyList() }
        } else {
            listOf(LiveChannelItem(url, title))
        }
    }

    var currentIndex by remember { mutableStateOf(startIndex) }
    var currentTitle by remember(title) { mutableStateOf(title) }
    var isControlsVisible by remember { mutableStateOf(true) }
    var hideJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }
    var showInfo by remember { mutableStateOf(false) }
    var infoText by remember { mutableStateOf("") }
    var exoPlayerState by remember { mutableStateOf<ExoPlayer?>(null) }
    var playerViewState by remember { mutableStateOf<PlayerView?>(null) }
    var isPlaying by remember { mutableStateOf(true) }
    var failedChannels = remember { mutableSetOf<Int>() }
    var ioErrorRetries = remember { mutableMapOf<Int, Int>() }
    var currentScaleMode by remember { mutableIntStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }

    val containerFocusRequester = remember { FocusRequester() }
    val backFocusRequester = remember { FocusRequester() }

    val scaleModes = listOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT to "Fit",
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM to "Zoom",
        AspectRatioFrameLayout.RESIZE_MODE_FILL to "Fill",
        AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH to "Fixed Width",
        AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT to "Fixed Height"
    )

    fun resetAutoHideTimer() {
        hideJob?.cancel()
        hideJob = scope.launch {
            delay(5000)
            isControlsVisible = false
        }
    }

    fun startAutoHideTimer() {
        resetAutoHideTimer()
    }

    LaunchedEffect(Unit) { startAutoHideTimer() }

    fun showControlsTemporarily() {
        hideJob?.cancel()
        isControlsVisible = true
        resetAutoHideTimer()
    }

    LaunchedEffect(isControlsVisible) {
        if (isControlsVisible) {
            delay(50)
            containerFocusRequester.requestFocus()
        }
    }

    fun showInfoTemporarily(text: String) {
        infoText = text
        showInfo = true
        scope.launch {
            delay(2000)
            showInfo = false
        }
        resetAutoHideTimer()
    }

    fun cycleScaleMode() {
        val currentIdx = scaleModes.indexOfFirst { it.first == currentScaleMode }
        val nextIdx = (currentIdx + 1) % scaleModes.size
        currentScaleMode = scaleModes[nextIdx].first
        playerViewState?.resizeMode = currentScaleMode
        showInfoTemporarily("Scale: ${scaleModes[nextIdx].second}")
        resetAutoHideTimer()
    }

    fun switchToNextChannel() {
        if (channels.isNotEmpty()) {
            val nextIndex = (currentIndex + 1) % channels.size
            failedChannels.clear()
            ioErrorRetries.clear()
            currentIndex = nextIndex
            currentTitle = channels[nextIndex].title
            exoPlayerState?.seekToDefaultPosition(nextIndex)
            exoPlayerState?.playWhenReady = true
            exoPlayerState?.play()
            showInfoTemporarily("Channel: ${channels[nextIndex].title}")
            resetAutoHideTimer()
        }
    }

    fun switchToPreviousChannel() {
        if (channels.isNotEmpty()) {
            val prevIndex = if (currentIndex > 0) currentIndex - 1 else channels.size - 1
            failedChannels.clear()
            ioErrorRetries.clear()
            currentIndex = prevIndex
            currentTitle = channels[prevIndex].title
            exoPlayerState?.seekToDefaultPosition(prevIndex)
            exoPlayerState?.playWhenReady = true
            exoPlayerState?.play()
            showInfoTemporarily("Channel: ${channels[prevIndex].title}")
            resetAutoHideTimer()
        }
    }

    val headers = mapOf(
        "User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Referer" to "http://dhakamovie.com/",
        "Origin" to "http://dhakamovie.com"
    )

    val httpDataSourceFactory = DefaultHttpDataSource.Factory()
        .setUserAgent("Mozilla/5.0")
        .setDefaultRequestProperties(headers)
        .setConnectTimeoutMs(30000)
        .setReadTimeoutMs(30000)
        .setAllowCrossProtocolRedirects(true)

    val loadControl = DefaultLoadControl.Builder()
        .setBufferDurationsMs(3000, 10000, 1500, 2000)
        .setPrioritizeTimeOverSizeThresholds(true)
        .setTargetBufferBytes(15 * 1024 * 1024)
        .build()

    val mediaItems = channels.map { channel ->
        MediaItem.Builder()
            .setUri(Uri.parse(channel.url))
            .setLiveConfiguration(
                MediaItem.LiveConfiguration.Builder()
                    .setTargetOffsetMs(3000)
                    .setMaxOffsetMs(6000)
                    .setMinOffsetMs(1000)
                    .setMaxPlaybackSpeed(1.1f)
                    .setMinPlaybackSpeed(0.95f)
                    .build()
            )
            .build()
    }

    val exoPlayer = remember {
        ExoPlayer.Builder(context)
            .setLoadControl(loadControl)
            .build()
            .apply {
                if (mediaItems.isNotEmpty()) {
                    setMediaItems(mediaItems, currentIndex, 0L)
                } else {
                    setMediaItem(MediaItem.fromUri(Uri.parse(url)))
                }
                prepare()
                playWhenReady = true
                play()
            }.also { exoPlayerState = it }
    }

    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                when (state) {
                    Player.STATE_READY -> {
                        failedChannels.clear()
                        ioErrorRetries.clear()
                    }
                    Player.STATE_ENDED -> {
                        exoPlayer.seekToDefaultPosition()
                        exoPlayer.play()
                        resetAutoHideTimer()
                    }
                }
            }

            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                val isIOError = error.errorCode == 2000 || error.errorCode == 2004
                if (isIOError) {
                    val retryCount = ioErrorRetries.getOrDefault(currentIndex, 0)
                    if (retryCount < 3) {
                        ioErrorRetries[currentIndex] = retryCount + 1
                        scope.launch {
                            delay(1000)
                            exoPlayer.seekToDefaultPosition(currentIndex)
                            exoPlayer.playWhenReady = true
                            exoPlayer.play()
                            resetAutoHideTimer()
                        }
                        return
                    }
                    failedChannels.add(currentIndex)
                    var nextIndex = (currentIndex + 1) % channels.size
                    var attempts = 0
                    while (nextIndex in failedChannels && attempts < channels.size) {
                        nextIndex = (nextIndex + 1) % channels.size
                        attempts++
                    }
                    if (attempts < channels.size) {
                        currentIndex = nextIndex
                        currentTitle = channels[nextIndex].title
                        showInfoTemporarily("Switching... (${failedChannels.size + 1}/${channels.size} failed)")
                        exoPlayer.seekToDefaultPosition(nextIndex)
                        exoPlayer.playWhenReady = true
                        exoPlayer.play()
                        resetAutoHideTimer()
                    } else {
                        showInfoTemporarily("All channels unavailable")
                    }
                }
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    DisposableEffect(Unit) {
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        activity?.window?.decorView?.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                )
        onDispose {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
            activity?.window?.decorView?.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        }
    }

    fun handleKeyEvent(key: Key, type: KeyEventType): Boolean {
        if (type == KeyEventType.KeyDown) {
            resetAutoHideTimer()
            val player = exoPlayerState ?: return false
            when (key.nativeKeyCode) {
                AndroidKeyEvent.KEYCODE_DPAD_CENTER, AndroidKeyEvent.KEYCODE_ENTER -> {
                    if (!isControlsVisible) {
                        showControlsTemporarily()
                        return true
                    }
                    return false
                }
                // Left/Right: switch channels only when controls are hidden
                AndroidKeyEvent.KEYCODE_DPAD_LEFT -> {
                    if (!isControlsVisible) {
                        switchToPreviousChannel()
                        return true
                    }
                    return false
                }
                AndroidKeyEvent.KEYCODE_DPAD_RIGHT -> {
                    if (!isControlsVisible) {
                        switchToNextChannel()
                        return true
                    }
                    return false
                }
                // Channel up/down, Page Up/Down, +/- always switch channels
                AndroidKeyEvent.KEYCODE_CHANNEL_DOWN,
                AndroidKeyEvent.KEYCODE_MINUS,
                AndroidKeyEvent.KEYCODE_PAGE_DOWN -> {
                    switchToPreviousChannel()
                    return true
                }
                AndroidKeyEvent.KEYCODE_CHANNEL_UP,
                AndroidKeyEvent.KEYCODE_PLUS,
                AndroidKeyEvent.KEYCODE_PAGE_UP -> {
                    switchToNextChannel()
                    return true
                }
                AndroidKeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                    if (player.isPlaying) player.pause()
                    else player.play()
                    showControlsTemporarily()
                    return true
                }
                AndroidKeyEvent.KEYCODE_BACK, AndroidKeyEvent.KEYCODE_ESCAPE -> {
                    navController.popBackStack()
                    return true
                }
            }
        }
        return false
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .focusRequester(containerFocusRequester)
            .focusable()
            .onFocusChanged { resetAutoHideTimer() }
            .onKeyEvent { handleKeyEvent(it.key, it.type) }
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = false
                    keepScreenOn = true
                    setShowNextButton(false)
                    setShowPreviousButton(false)
                    resizeMode = currentScaleMode
                    setOnClickListener {
                        showControlsTemporarily()
                        resetAutoHideTimer()
                    }
                }.also { playerViewState = it }
            },
            modifier = Modifier.fillMaxSize()
        )

        AnimatedVisibility(
            visible = isControlsVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                // Top bar
                Surface(
                    modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().zIndex(2f),
                    color = Color.Black.copy(alpha = 0.7f),
                    shape = RoundedCornerShape(bottomStart = 12.dp, bottomEnd = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        var isBackFocused by remember { mutableStateOf(false) }
                        IconButton(
                            onClick = {
                                navController.popBackStack()
                                resetAutoHideTimer()
                            },
                            modifier = Modifier
                                .focusRequester(backFocusRequester)
                                .onFocusChanged { isBackFocused = it.isFocused }
                                .then(if (isBackFocused) Modifier.border(2.dp, Color.Yellow, RoundedCornerShape(8.dp)) else Modifier)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = if (isBackFocused) Color.Yellow else Color.White)
                        }

                        Text(
                            currentTitle,
                            modifier = Modifier.weight(1f).padding(start = 8.dp),
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1
                        )

                        // Scale button
                        var isScaleFocused by remember { mutableStateOf(false) }
                        IconButton(
                            onClick = {
                                cycleScaleMode()
                                resetAutoHideTimer()
                            },
                            modifier = Modifier
                                .size(64.dp)
                                .onFocusChanged { isScaleFocused = it.isFocused }
                                .then(if (isScaleFocused) Modifier.border(2.dp, Color.Yellow, RoundedCornerShape(8.dp)) else Modifier)
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    Icons.Filled.ZoomOutMap,
                                    "Scale",
                                    tint = if (isScaleFocused) Color.Yellow else Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                                Text(
                                    "Scale",
                                    color = if (isScaleFocused) Color.Yellow else Color.White,
                                    fontSize = 10.sp,
                                    maxLines = 1
                                )
                            }
                        }

                        if (channels.size > 1) {
                            Text(
                                "${currentIndex + 1}/${channels.size}",
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 14.sp,
                                modifier = Modifier.padding(horizontal = 8.dp)
                            )
                        }
                    }
                }

                // Bottom controls
                Surface(
                    modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(16.dp),
                    color = Color.Black.copy(alpha = 0.7f),
                    shape = RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        var isPrevFocused by remember { mutableStateOf(false) }
                        IconButton(
                            onClick = {
                                switchToPreviousChannel()
                                resetAutoHideTimer()
                            },
                            modifier = Modifier
                                .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .onFocusChanged { isPrevFocused = it.isFocused }
                                .then(if (isPrevFocused) Modifier.border(2.dp, Color.Yellow, RoundedCornerShape(8.dp)) else Modifier)
                        ) {
                            Icon(Icons.Filled.SkipPrevious, "Previous", tint = Color.White)
                        }

                        var isPlayFocused by remember { mutableStateOf(false) }
                        IconButton(
                            onClick = {
                                if (isPlaying) exoPlayerState?.pause() else exoPlayerState?.play()
                                showControlsTemporarily()
                                resetAutoHideTimer()
                            },
                            modifier = Modifier
                                .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .onFocusChanged { isPlayFocused = it.isFocused }
                                .then(if (isPlayFocused) Modifier.border(2.dp, Color.Yellow, RoundedCornerShape(8.dp)) else Modifier)
                        ) {
                            Icon(if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Play/Pause", tint = Color.White, modifier = Modifier.size(48.dp))
                        }

                        var isNextFocused by remember { mutableStateOf(false) }
                        IconButton(
                            onClick = {
                                switchToNextChannel()
                                resetAutoHideTimer()
                            },
                            modifier = Modifier
                                .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .onFocusChanged { isNextFocused = it.isFocused }
                                .then(if (isNextFocused) Modifier.border(2.dp, Color.Yellow, RoundedCornerShape(8.dp)) else Modifier)
                        ) {
                            Icon(Icons.Filled.SkipNext, "Next", tint = Color.White)
                        }
                    }
                }
            }
        }

        // Info overlay
        AnimatedVisibility(
            visible = showInfo,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 180.dp)
        ) {
            Surface(color = Color.Black.copy(alpha = 0.8f), shape = RoundedCornerShape(8.dp), modifier = Modifier.padding(16.dp)) {
                Text(infoText, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp))
            }
        }
    }

    LaunchedEffect(Unit) { containerFocusRequester.requestFocus() }
}