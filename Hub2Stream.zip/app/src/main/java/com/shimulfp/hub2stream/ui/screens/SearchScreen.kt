package com.shimulfp.hub2stream.ui.screens

import android.app.Application
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.shimulfp.hub2stream.extractor.models.MediaItemPreview
import com.shimulfp.hub2stream.ui.components.MoviePoster
import com.shimulfp.hub2stream.ui.navigation.Screen
import com.shimulfp.hub2stream.viewmodels.SearchViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    navController: NavController
) {
    val context = LocalContext.current
    val application = context.applicationContext as Application
    val viewModel: SearchViewModel = viewModel(
        factory = object : ViewModelProvider.Factory {
            override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
                @Suppress("UNCHECKED_CAST")
                return SearchViewModel(application) as T
            }
        }
    )

    var query by remember { mutableStateOf("") }
    val searchResults by viewModel.searchResults.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val error by viewModel.error.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Search") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, null)
                    }
                },
                actions = {
                    IconButton(onClick = {
                        if (query.isNotBlank()) {
                            viewModel.search(query)
                        }
                    }) {
                        Icon(Icons.Filled.Search, null)
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Search movies or series") },
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                singleLine = true,
                trailingIcon = {
                    IconButton(onClick = {
                        if (query.isNotBlank()) {
                            viewModel.search(query)
                        }
                    }) {
                        Icon(Icons.Filled.Search, null)
                    }
                }
            )
            when {
                isLoading -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                    CircularProgressIndicator()
                }
                error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Text("Error: $error")
                }
                searchResults.isEmpty() && query.isNotBlank() -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Text("No results found")
                }
                else -> {
                    val columns = if (LocalContext.current.resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE) 6 else 3
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(columns),
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(searchResults) { item ->
                            MoviePoster(
                                item = item,
                                onClick = {
                                    when (item) {
                                        is MediaItemPreview.MoviePreview -> navController.navigate(Screen.MovieDetail.pass(item.slug))
                                        is MediaItemPreview.SeriesPreview -> navController.navigate(Screen.SeriesDetail.pass(item.slug))
                                    }
                                },
                                requestFocus = searchResults.indexOf(item) == 0
                            )
                        }
                    }
                }
            }
        }
    }
}