package com.shimulfp.hub2stream.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.shimulfp.hub2stream.extractor.models.LiveChannel
import com.shimulfp.hub2stream.extractor.models.MediaItemPreview
import com.shimulfp.hub2stream.extractor.models.SportsEvent
import com.shimulfp.hub2stream.models.ContinueWatchingItem
import com.shimulfp.hub2stream.ui.components.CategoryRow
import com.shimulfp.hub2stream.ui.components.ContinueWatchingCard
import com.shimulfp.hub2stream.ui.components.MoviePoster
import com.shimulfp.hub2stream.ui.navigation.Screen
import com.shimulfp.hub2stream.utils.CategoryCache
import com.shimulfp.hub2stream.viewmodels.HomeViewModel
import java.net.URLEncoder

@OptIn(ExperimentalFoundationApi::class, ExperimentalComposeUiApi::class, ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(navController: NavController, viewModel: HomeViewModel = viewModel()) {
    val uiState by viewModel.uiState.collectAsState()
    val firstRowFocusRequester = remember { FocusRequester() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Hub2Stream") },
                actions = {
                    IconButton(onClick = { navController.navigate(Screen.Search.route) }) {
                        Icon(Icons.Filled.Search, contentDescription = "Search")
                    }
                }
            )
        }
    ) { paddingValues ->
        if (uiState.isLoadingMovies && uiState.isLoadingLiveTV && uiState.isLoadingSports &&
            uiState.movieRows.isEmpty() && uiState.liveChannels.isEmpty() && uiState.liveEvents.isEmpty() &&
            uiState.continueWatchingItems.isEmpty()
        ) {
            Box(modifier = Modifier.fillMaxSize().padding(paddingValues), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier.padding(paddingValues),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            // 1. Continue Watching row
            if (uiState.continueWatchingItems.isNotEmpty()) {
                item {
                    CategoryRow(
                        title = "Continue Watching",
                        items = uiState.continueWatchingItems,
                        onItemClick = { item: ContinueWatchingItem ->
                            when (item.type) {
                                "movie" -> navController.navigate(
                                    Screen.MovieDetail.pass(item.slug, item.positionSeconds * 1000L)
                                )
                                "series" -> navController.navigate(
                                    Screen.SeriesDetail.pass(
                                        slug = item.slug,
                                        season = item.seasonNumber,
                                        episode = item.episodeNumber,
                                        resumePosition = item.positionSeconds * 1000L
                                    )
                                )
                            }
                        },
                        onMoreClick = { /* TODO */ },
                        posterContent = { item: ContinueWatchingItem, requestFocus: Boolean ->
                            ContinueWatchingCard(
                                item = item,
                                onClick = {
                                    when (item.type) {
                                        "movie" -> navController.navigate(
                                            Screen.Player.pass(
                                                url = "",
                                                title = item.title,
                                                isLive = false,
                                                slug = item.slug,
                                                poster = item.posterUrl,
                                                type = item.type,
                                                resumePosition = item.positionSeconds * 1000L
                                            )
                                        )
                                        "series" -> navController.navigate(
                                            Screen.SeriesDetail.pass(
                                                slug = item.slug,
                                                season = item.seasonNumber,
                                                episode = item.episodeNumber,
                                                resumePosition = item.positionSeconds * 1000L
                                            )
                                        )
                                    }
                                },
                                requestFocus = requestFocus
                            )
                        },
                        isFirstRow = true,
                        rowFocusRequester = firstRowFocusRequester
                    )
                }
            }

            // 2. Live Sports Carousel
            if (uiState.liveEvents.isNotEmpty()) {
                item {
                    Column {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Live Sports", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            TextButton(onClick = { navController.navigate(Screen.LiveSports.route) }) {
                                Text("More", color = MaterialTheme.colorScheme.primary)
                                Icon(Icons.AutoMirrored.Filled.ArrowForward, null, Modifier.size(16.dp))
                            }
                        }
                        SportsCarousel(uiState.liveEvents) { event ->
                            playSportsEventWithPlaylist(navController, uiState.liveEvents, event)
                        }
                    }
                }
            } else if (uiState.isLoadingSports) {
                item { Box(Modifier.fillMaxWidth().height(200.dp), Alignment.Center) { CircularProgressIndicator() } }
            }

            // 3. Live TV row
            if (uiState.liveChannels.isNotEmpty()) {
                item {
                    CategoryRow(
                        title = "Live TV",
                        items = uiState.liveChannels,
                        onItemClick = { channel -> playChannelWithPlaylist(navController, uiState.liveChannels, channel) },
                        onMoreClick = { navController.navigate(Screen.LiveTV.route) },
                        posterContent = { channel, requestFocus ->
                            ChannelCard(
                                channel = channel,
                                onClick = { playChannelWithPlaylist(navController, uiState.liveChannels, channel) },
                                modifier = Modifier.width(120.dp).height(180.dp),
                                requestFocus = requestFocus
                            )
                        }
                    )
                }
            } else if (uiState.isLoadingLiveTV) {
                item { Box(Modifier.fillMaxWidth().height(100.dp), Alignment.Center) { CircularProgressIndicator() } }
            }

            // 4. Movie & Series rows
            if (uiState.movieRows.isNotEmpty()) {
                items(uiState.movieRows.size) { idx ->
                    val row = uiState.movieRows[idx]

                    val categoryForMore = when (row.title) {
                        "Korean TV Series" -> "Korean+Series"
                        "Indian TV Series" -> "Indian+Series"
                        "Turkish TV Series" -> "Turkish+Series"
                        "Bangla Drama" -> "Bangla+Drama"
                        "Hindi Series" -> "Hindi+Series"
                        "English Series" -> "English+Series"
                        else -> null
                    }

                    CategoryRow(
                        title = row.title,
                        items = row.items,
                        onItemClick = { item ->
                            when (item) {
                                is MediaItemPreview.MoviePreview -> navController.navigate(Screen.MovieDetail.pass(item.slug))
                                is MediaItemPreview.SeriesPreview -> navController.navigate(Screen.SeriesDetail.pass(item.slug))
                            }
                        },
                        onMoreClick = {
                            if (categoryForMore != null) {
                                navController.navigate(Screen.Category.pass(row.title, true, categoryForMore))
                            } else {
                                CategoryCache.currentItems = row.items
                                navController.navigate(Screen.Category.pass(row.title, false))
                            }
                        },
                        posterContent = { item, requestFocus ->
                            MoviePoster(
                                item = item,
                                onClick = {
                                    when (item) {
                                        is MediaItemPreview.MoviePreview -> navController.navigate(Screen.MovieDetail.pass(item.slug))
                                        is MediaItemPreview.SeriesPreview -> navController.navigate(Screen.SeriesDetail.pass(item.slug))
                                    }
                                },
                                requestFocus = requestFocus
                            )
                        }
                    )
                }
            } else if (uiState.isLoadingMovies) {
                item { Box(Modifier.fillMaxWidth().height(100.dp), Alignment.Center) { CircularProgressIndicator() } }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SportsCarousel(events: List<SportsEvent>, onEventClick: (SportsEvent) -> Unit) {
    val pagerState = rememberPagerState(pageCount = { events.size })
    HorizontalPager(
        state = pagerState,
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 16.dp)
    ) { page ->
        SportsEventLargeCard(
            event = events[page],
            onClick = { onEventClick(events[page]) },
            requestFocus = page == 0
        )
    }
    if (events.size > 1) {
        Row(
            Modifier.fillMaxWidth().padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            repeat(events.size) { i ->
                val color = if (pagerState.currentPage == i) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f)
                Box(Modifier.padding(4.dp).size(8.dp).background(color, CircleShape))
            }
        }
    }
}

private fun playChannelWithPlaylist(
    navController: NavController,
    allChannels: List<LiveChannel>,
    selected: LiveChannel
) {
    val playlist = allChannels.map { mapOf("url" to it.streamUrl, "title" to it.name) }
    val json = jacksonObjectMapper().writeValueAsString(playlist)
    navController.navigate(
        Screen.LivePlayer.pass(
            url = selected.streamUrl,
            title = selected.name,
            channelsJson = URLEncoder.encode(json, "UTF-8"),
            startIndex = allChannels.indexOf(selected)
        )
    )
}

private fun playSportsEventWithPlaylist(
    navController: NavController,
    allEvents: List<SportsEvent>,
    selected: SportsEvent
) {
    val playlist = allEvents.map { mapOf("url" to it.streamUrl, "title" to it.name) }
    val json = jacksonObjectMapper().writeValueAsString(playlist)
    navController.navigate(
        Screen.LivePlayer.pass(
            url = selected.streamUrl,
            title = selected.name,
            channelsJson = URLEncoder.encode(json, "UTF-8"),
            startIndex = allEvents.indexOf(selected)
        )
    )
}