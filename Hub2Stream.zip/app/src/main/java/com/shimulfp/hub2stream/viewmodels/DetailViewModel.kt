package com.shimulfp.hub2stream.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.shimulfp.hub2stream.data.MovieRepository
import com.shimulfp.hub2stream.extractor.models.Movie
import com.shimulfp.hub2stream.extractor.models.Series
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

sealed class DetailUiState {
    object Loading : DetailUiState()
    data class MovieSuccess(val movie: Movie) : DetailUiState()
    data class SeriesSuccess(val series: Series) : DetailUiState()
    data class Error(val message: String) : DetailUiState()
}

class DetailViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = MovieRepository(application)
    private val _uiState = MutableStateFlow<DetailUiState>(DetailUiState.Loading)
    val uiState: StateFlow<DetailUiState> = _uiState

    fun loadMovie(slug: String) {
        viewModelScope.launch {
            _uiState.value = DetailUiState.Loading
            try {
                val movie = repo.getMovieDetails(slug)
                if (movie != null) _uiState.value = DetailUiState.MovieSuccess(movie)
                else _uiState.value = DetailUiState.Error("Movie not found")
            } catch (e: Exception) { _uiState.value = DetailUiState.Error(e.message ?: "Unknown error") }
        }
    }

    fun loadSeries(slug: String) {
        viewModelScope.launch {
            _uiState.value = DetailUiState.Loading
            try {
                val series = repo.getSeriesDetails(slug)
                if (series != null) _uiState.value = DetailUiState.SeriesSuccess(series)
                else _uiState.value = DetailUiState.Error("Series not found")
            } catch (e: Exception) { _uiState.value = DetailUiState.Error(e.message ?: "Unknown error") }
        }
    }
}