package com.shimulfp.hub2stream.utils

import com.shimulfp.hub2stream.extractor.models.MediaItemPreview

object CategoryCache {
    var currentItems: List<MediaItemPreview> = emptyList()
}