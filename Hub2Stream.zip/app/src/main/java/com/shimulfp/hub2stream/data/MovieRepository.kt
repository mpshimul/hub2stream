package com.shimulfp.hub2stream.data

import android.app.Application
import com.shimulfp.hub2stream.extractor.MovieBoxExtractor
import com.shimulfp.hub2stream.extractor.models.*

class MovieRepository(private val appContext: Application) {
    private val extractor = MovieBoxExtractor()

    suspend fun getHomePageRows(): List<HomePageRow> = extractor.getHomePageRows()
    suspend fun getAllSeriesByCategory(category: String?): List<Series> = extractor.getAllSeriesByCategory(category)
    suspend fun getMovieDetails(slug: String): Movie? = extractor.getMovieDetails(slug)
    suspend fun getSeriesDetails(slug: String): Series? = extractor.getSeriesDetails(slug)

    suspend fun loadLinks(linkData: String, callback: (String, String, String?) -> Unit) {
        extractor.loadLinks(linkData, callback)
    }

    suspend fun getStreams(linkData: String, callback: (List<QualityInfo>, String?) -> Unit) {
        extractor.getStreams(linkData, callback)
    }

    suspend fun search(query: String, page: Int = 1): List<MediaItemPreview> {
        return extractor.search(query, page)
    }

    suspend fun fetchSubtitles(
        subjectId: String,
        resourceId: String,
        detailPath: String,
        format: String = "MP4"
    ): List<SubtitleInfo> = extractor.fetchSubtitles(subjectId, resourceId, detailPath, format)
}