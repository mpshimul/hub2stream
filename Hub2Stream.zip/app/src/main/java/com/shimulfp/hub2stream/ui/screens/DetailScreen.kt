package com.shimulfp.hub2stream.ui.screens

import android.app.Application
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.shimulfp.hub2stream.extractor.models.Episode
import com.shimulfp.hub2stream.extractor.models.Series
import com.shimulfp.hub2stream.ui.navigation.Screen
import com.shimulfp.hub2stream.viewmodels.DetailUiState
import com.shimulfp.hub2stream.viewmodels.DetailViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MovieDetailScreen(
    navController: NavController,
    slug: String,
    resumePosition: Long = 0L
) {
    val context = LocalContext.current
    val application = context.applicationContext as Application
    val viewModel: DetailViewModel = viewModel(
        factory = object : ViewModelProvider.Factory {
            override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
                @Suppress("UNCHECKED_CAST")
                return DetailViewModel(application) as T
            }
        }
    )

    LaunchedEffect(slug) { viewModel.loadMovie(slug) }
    val uiState by viewModel.uiState.collectAsState()

    when (val state = uiState) {
        is DetailUiState.Loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
        is DetailUiState.MovieSuccess -> MovieDetailLayout(
            title = state.movie.title,
            posterUrl = state.movie.posterUrl,
            backdropUrl = state.movie.backdropUrl,
            year = state.movie.year?.toString() ?: "",
            rating = state.movie.rating?.toString() ?: "",
            genres = state.movie.genres,
            plot = state.movie.plot,
            onPlayClick = {
                navController.navigate(
                    Screen.Player.pass(
                        url = state.movie.streamUrl,
                        title = state.movie.title,
                        isLive = false,
                        slug = slug,
                        poster = state.movie.posterUrl,
                        type = "movie",
                        resumePosition = resumePosition
                    )
                )
            },
            onBackClick = { navController.popBackStack() }
        )
        is DetailUiState.Error -> Box(Modifier.fillMaxSize(), Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Error: ${state.message}")
                Button(onClick = { viewModel.loadMovie(slug) }) { Text("Retry") }
            }
        }
        else -> {}
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SeriesDetailScreen(
    navController: NavController,
    slug: String,
    season: Int = 0,
    episode: Int = 0,
    resumePosition: Long = 0L
) {
    val context = LocalContext.current
    val application = context.applicationContext as Application
    val viewModel: DetailViewModel = viewModel(
        factory = object : ViewModelProvider.Factory {
            override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
                @Suppress("UNCHECKED_CAST")
                return DetailViewModel(application) as T
            }
        }
    )

    LaunchedEffect(slug) { viewModel.loadSeries(slug) }
    val uiState by viewModel.uiState.collectAsState()

    when (val state = uiState) {
        is DetailUiState.Loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
        is DetailUiState.SeriesSuccess -> {
            val series = state.series
            val allEpisodes = series.seasons.flatMap { it.episodes }
            val limitedEpisodes = allEpisodes.take(200)

            // Auto‑play if season/episode specified
            LaunchedEffect(season, episode) {
                if (season > 0 && episode > 0) {
                    val targetSeason = series.seasons.find { it.seasonNumber == season }
                    val targetEpisode = targetSeason?.episodes?.find { it.episodeNumber == episode }
                    if (targetEpisode != null) {
                        val episodesList = limitedEpisodes.mapIndexed { idx, ep ->
                            mapOf("url" to ep.filePath, "title" to "${series.title} - ${ep.title}")
                        }
                        val mapper = jacksonObjectMapper()
                        val episodesJson = mapper.writeValueAsString(episodesList)
                        val currentIndex = limitedEpisodes.indexOf(targetEpisode)
                        navController.navigate(
                            Screen.Player.pass(
                                url = targetEpisode.filePath,
                                title = "${series.title} - ${targetEpisode.title}",
                                episodesJson = episodesJson,
                                startIndex = currentIndex,
                                isLive = false,
                                slug = slug,
                                poster = series.posterUrl,
                                type = "series",
                                season = season,
                                episode = episode,
                                resumePosition = resumePosition
                            )
                        )
                    }
                }
            }

            SeriesCloudStreamLayout(
                series = series,
                onBackClick = { navController.popBackStack() },
                onEpisodeClick = { clickedEpisode ->
                    val episodesList = limitedEpisodes.mapIndexed { idx, ep ->
                        mapOf("url" to ep.filePath, "title" to "${series.title} - ${ep.title}")
                    }
                    val mapper = jacksonObjectMapper()
                    val episodesJson = mapper.writeValueAsString(episodesList)
                    val currentIndex = limitedEpisodes.indexOf(clickedEpisode)
                    navController.navigate(
                        Screen.Player.pass(
                            url = clickedEpisode.filePath,
                            title = "${series.title} - ${clickedEpisode.title}",
                            episodesJson = episodesJson,
                            startIndex = currentIndex,
                            isLive = false,
                            slug = slug,
                            poster = series.posterUrl,
                            type = "series",
                            season = clickedEpisode.episodeNumber, // approximate
                            episode = clickedEpisode.episodeNumber,
                            resumePosition = 0L
                        )
                    )
                }
            )
        }
        is DetailUiState.Error -> Box(Modifier.fillMaxSize(), Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Error: ${state.message}")
                Button(onClick = { viewModel.loadSeries(slug) }) { Text("Retry") }
            }
        }
        else -> {}
    }
}

// The rest of the file (MovieDetailLayout, SeriesCloudStreamLayout, EpisodeCard, Chip) remains unchanged
// Copy them from your original DetailScreen.kt or from the previous code.
// I'll include them here for completeness:

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MovieDetailLayout(
    title: String,
    posterUrl: String,
    backdropUrl: String,
    year: String,
    rating: String,
    genres: List<String>,
    plot: String,
    onPlayClick: (() -> Unit)? = null,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title, maxLines = 1) },
                navigationIcon = { IconButton(onClick = onBackClick) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent,
                    scrolledContainerColor = MaterialTheme.colorScheme.surface
                ),
                modifier = Modifier.background(
                    Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.7f), Color.Transparent))
                )
            )
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.padding(padding), contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                Box(Modifier.fillMaxWidth().height(300.dp)) {
                    AsyncImage(
                        model = ImageRequest.Builder(context).data(backdropUrl.ifBlank { posterUrl }).crossfade(true).build(),
                        contentDescription = title,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f)), startY = 0.6f)))
                }
            }
            item {
                Column(Modifier.padding(16.dp)) {
                    Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        if (year.isNotBlank()) Chip { Text(year, fontSize = 12.sp) }
                        if (rating.isNotBlank()) Chip { Text("⭐ $rating", fontSize = 12.sp) }
                    }
                    if (genres.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            genres.take(3).forEach { genre -> Text(genre, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary) }
                        }
                    }
                }
            }
            if (onPlayClick != null) {
                item {
                    Button(
                        onClick = onPlayClick,
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("▶ PLAY NOW", fontWeight = FontWeight.Bold)
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), shape = RoundedCornerShape(12.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Synopsis", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(plot.ifBlank { "No synopsis available." }, fontSize = 14.sp, lineHeight = 20.sp)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SeriesCloudStreamLayout(
    series: Series,
    onBackClick: () -> Unit,
    onEpisodeClick: (Episode) -> Unit,
    initialSeason: Int = 1   // new parameter
) {
    var selectedSeason by remember { mutableStateOf(initialSeason) }
    val currentSeason = series.seasons.find { it.seasonNumber == selectedSeason }
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(series.title, maxLines = 1) },
                navigationIcon = { IconButton(onClick = onBackClick) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent,
                    scrolledContainerColor = MaterialTheme.colorScheme.surface
                ),
                modifier = Modifier.background(
                    Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.7f), Color.Transparent))
                )
            )
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.padding(padding)) {
            item {
                Box(Modifier.fillMaxWidth().height(300.dp)) {
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data(series.backdropUrl.ifBlank { series.posterUrl })
                            .crossfade(true)
                            .build(),
                        contentDescription = series.title,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f)), startY = 0.6f)))
                }
            }
            item {
                Column(Modifier.padding(16.dp)) {
                    Text(series.title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        if (series.year != null) Chip { Text(series.year.toString(), fontSize = 12.sp) }
                        if (series.rating != null) Chip { Text("⭐ ${series.rating}", fontSize = 12.sp) }
                    }
                    if (series.genres.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            series.genres.take(3).forEach { genre -> Text(genre, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary) }
                        }
                    }
                }
            }
            if (series.seasons.size > 1) {
                item {
                    LazyRow(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(series.seasons) { season ->
                            FilterChip(
                                selected = selectedSeason == season.seasonNumber,
                                onClick = { selectedSeason = season.seasonNumber },
                                label = { Text("Season ${season.seasonNumber}") }
                            )
                        }
                    }
                }
            }
            if (currentSeason != null) {
                item {
                    Text(
                        "Season ${currentSeason.seasonNumber}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp)
                    )
                }
                items(currentSeason.episodes) { episode ->
                    val isFirstEpisode = currentSeason.episodes.indexOf(episode) == 0
                    EpisodeCard(
                        episode = episode,
                        onClick = { onEpisodeClick(episode) },
                        requestFocus = isFirstEpisode
                    )
                }
            }
            item {
                Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), shape = RoundedCornerShape(12.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Synopsis", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(series.plot.ifBlank { "No synopsis available." }, fontSize = 14.sp, lineHeight = 20.sp)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun EpisodeCard(episode: Episode, onClick: () -> Unit, requestFocus: Boolean = false) {
    var isFocused by remember { mutableStateOf(false) }
    val focusRequester = remember { FocusRequester() }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .focusRequester(focusRequester)
            .onFocusChanged { isFocused = it.isFocused }
            .then(
                if (isFocused) Modifier
                    .border(2.dp, Color.Yellow, RoundedCornerShape(12.dp))
                else Modifier
            )
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(if (isFocused) 8.dp else 2.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${episode.episodeNumber}. ${episode.title}",
                    fontWeight = if (isFocused) FontWeight.Bold else FontWeight.Medium,
                    fontSize = 16.sp,
                    color = if (isFocused) Color.Yellow else Color.Unspecified
                )
                if (episode.runtime != null) {
                    Text(
                        text = "${episode.runtime} min",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            if (isFocused) {
                Icon(
                    Icons.Filled.PlayArrow,
                    contentDescription = "Play",
                    modifier = Modifier.size(24.dp),
                    tint = Color.Yellow
                )
            } else {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Play",
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }

    if (requestFocus) {
        LaunchedEffect(Unit) {
            focusRequester.requestFocus()
        }
    }
}

@Composable
fun Chip(shape: RoundedCornerShape = RoundedCornerShape(4.dp), content: @Composable () -> Unit) {
    Surface(shape = shape, color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.8f)) {
        Box(Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) { content() }
    }
}