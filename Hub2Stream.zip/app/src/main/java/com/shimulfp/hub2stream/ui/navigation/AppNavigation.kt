package com.shimulfp.hub2stream.ui.navigation

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.shimulfp.hub2stream.ui.screens.*

sealed class Screen(val route: String) {
    object Home : Screen("home")

    object MovieDetail : Screen("movie/{slug}/{resumePosition}") {
        fun pass(slug: String, resumePosition: Long = 0L) = "movie/$slug/$resumePosition"
    }

    object SeriesDetail : Screen("series/{slug}/{season}/{episode}/{resumePosition}") {
        fun pass(slug: String, season: Int = 0, episode: Int = 0, resumePosition: Long = 0L) =
            "series/$slug/$season/$episode/$resumePosition"
    }

    object Player : Screen("player?url={url}&title={title}&episodesJson={episodesJson}&startIndex={startIndex}&isLive={isLive}&slug={slug}&poster={poster}&type={type}&season={season}&episode={episode}&resumePosition={resumePosition}") {
        fun pass(
            url: String,
            title: String,
            episodesJson: String = "",
            startIndex: Int = 0,
            isLive: Boolean = false,
            slug: String = "",
            poster: String = "",
            type: String = "",
            season: Int = 0,
            episode: Int = 0,
            resumePosition: Long = 0L
        ): String {
            return buildString {
                append("player?url=${Uri.encode(url)}&title=${Uri.encode(title)}")
                if (episodesJson.isNotBlank()) append("&episodesJson=${Uri.encode(episodesJson)}")
                append("&startIndex=$startIndex&isLive=${if (isLive) "1" else "0"}")
                if (slug.isNotBlank()) append("&slug=${Uri.encode(slug)}")
                if (poster.isNotBlank()) append("&poster=${Uri.encode(poster)}")
                if (type.isNotBlank()) append("&type=${Uri.encode(type)}")
                if (season > 0) append("&season=$season")
                if (episode > 0) append("&episode=$episode")
                if (resumePosition > 0) append("&resumePosition=$resumePosition")
            }
        }
    }

    object LivePlayer : Screen("liveplayer?url={url}&title={title}&channelsJson={channelsJson}&startIndex={startIndex}") {
        fun pass(url: String, title: String, channelsJson: String = "", startIndex: Int = 0): String {
            return "liveplayer?url=${Uri.encode(url)}&title=${Uri.encode(title)}&channelsJson=${Uri.encode(channelsJson)}&startIndex=$startIndex"
        }
    }

    object LiveTV : Screen("live_tv")
    object LiveSports : Screen("live_sports")

    object Search : Screen("search")

    object Category : Screen("category/{title}/{isSeries}/{category}") {
        fun pass(title: String, isSeries: Boolean, category: String? = null): String {
            val categoryParam = category?.let { Uri.encode(it) } ?: "null"
            return "category/${Uri.encode(title)}/${if (isSeries) "1" else "0"}/$categoryParam"
        }
    }
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    NavHost(navController, startDestination = Screen.Home.route) {
        composable(Screen.Home.route) {
            HomeScreen(navController)
        }

        composable(Screen.Search.route) {
            SearchScreen(navController)
        }

        composable(
            route = Screen.MovieDetail.route,
            arguments = listOf(
                navArgument("slug") { type = NavType.StringType },
                navArgument("resumePosition") { type = NavType.LongType; defaultValue = 0L }
            )
        ) { backStackEntry ->
            val slug = backStackEntry.arguments?.getString("slug") ?: return@composable
            val resumePosition = backStackEntry.arguments?.getLong("resumePosition") ?: 0L
            MovieDetailScreen(navController, slug, resumePosition)
        }
        composable(
            route = Screen.SeriesDetail.route,
            arguments = listOf(
                navArgument("slug") { type = NavType.StringType },
                navArgument("season") { type = NavType.IntType; defaultValue = 0 },
                navArgument("episode") { type = NavType.IntType; defaultValue = 0 },
                navArgument("resumePosition") { type = NavType.LongType; defaultValue = 0L }
            )
        ) { backStackEntry ->
            val slug = backStackEntry.arguments?.getString("slug") ?: return@composable
            val season = backStackEntry.arguments?.getInt("season") ?: 0
            val episode = backStackEntry.arguments?.getInt("episode") ?: 0
            val resumePosition = backStackEntry.arguments?.getLong("resumePosition") ?: 0L
            SeriesDetailScreen(navController, slug, season, episode, resumePosition)
        }
        composable(
            route = Screen.Player.route,
            arguments = listOf(
                navArgument("url") { type = NavType.StringType },
                navArgument("title") { type = NavType.StringType },
                navArgument("episodesJson") { type = NavType.StringType; nullable = true },
                navArgument("startIndex") { type = NavType.IntType; defaultValue = 0 },
                navArgument("isLive") { type = NavType.StringType; defaultValue = "0" },
                navArgument("slug") { type = NavType.StringType; nullable = true },
                navArgument("poster") { type = NavType.StringType; nullable = true },
                navArgument("type") { type = NavType.StringType; nullable = true },
                navArgument("season") { type = NavType.IntType; defaultValue = 0 },
                navArgument("episode") { type = NavType.IntType; defaultValue = 0 },
                navArgument("resumePosition") { type = NavType.LongType; defaultValue = 0L }
            )
        ) { backStackEntry ->
            val url = backStackEntry.arguments?.getString("url") ?: return@composable
            val title = backStackEntry.arguments?.getString("title") ?: "Video"
            val episodesJson = backStackEntry.arguments?.getString("episodesJson") ?: ""
            val startIndex = backStackEntry.arguments?.getInt("startIndex") ?: 0
            val isLive = backStackEntry.arguments?.getString("isLive")?.toBoolean() ?: false
            val slug = backStackEntry.arguments?.getString("slug") ?: ""
            val poster = backStackEntry.arguments?.getString("poster") ?: ""
            val type = backStackEntry.arguments?.getString("type") ?: ""
            val season = backStackEntry.arguments?.getInt("season") ?: 0
            val episode = backStackEntry.arguments?.getInt("episode") ?: 0
            val resumePosition = backStackEntry.arguments?.getLong("resumePosition") ?: 0L
            PlayerScreen(navController, url, title, episodesJson, startIndex, isLive, slug, poster, type, season, episode, resumePosition)
        }
        composable(
            route = Screen.LivePlayer.route,
            arguments = listOf(
                navArgument("url") { type = NavType.StringType },
                navArgument("title") { type = NavType.StringType },
                navArgument("channelsJson") { type = NavType.StringType; nullable = true },
                navArgument("startIndex") { type = NavType.IntType; defaultValue = 0 }
            )
        ) { backStackEntry ->
            val url = backStackEntry.arguments?.getString("url") ?: return@composable
            val title = backStackEntry.arguments?.getString("title") ?: "Live TV"
            val channelsJson = backStackEntry.arguments?.getString("channelsJson") ?: ""
            val startIndex = backStackEntry.arguments?.getInt("startIndex") ?: 0
            LivePlayerScreen(navController, url, title, channelsJson, startIndex)
        }
        composable(Screen.LiveTV.route) {
            LiveTVScreen(navController)
        }
        composable(Screen.LiveSports.route) {
            LiveSportsScreen(navController)
        }
        composable(
            route = Screen.Category.route,
            arguments = listOf(
                navArgument("title") { type = NavType.StringType },
                navArgument("isSeries") { type = NavType.StringType },
                navArgument("category") { type = NavType.StringType; nullable = true }
            )
        ) { backStackEntry ->
            val title = backStackEntry.arguments?.getString("title") ?: return@composable
            val isSeries = backStackEntry.arguments?.getString("isSeries")?.toBoolean() ?: false
            val category = backStackEntry.arguments?.getString("category")
            CategoryScreen(navController, title, isSeries, category)
        }
    }
}