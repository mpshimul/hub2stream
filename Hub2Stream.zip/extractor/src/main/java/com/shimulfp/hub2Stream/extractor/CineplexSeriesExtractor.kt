package com.shimulfp.hub2stream.extractor

import com.fasterxml.jackson.core.type.TypeReference
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.fasterxml.jackson.module.kotlin.readValue
import com.shimulfp.hub2stream.extractor.models.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class CineplexSeriesExtractor {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val baseUrl = "http://cineplexbd.net"
    private val seriesListBase = "$baseUrl/tvs_more.php"
    private val seriesDetailUrl = "$baseUrl/watch.php"

    private val headers = mapOf(
        "User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept" to "application/json"
    )

    private val MAX_SERIES_FOR_HOME = 20
    private val MAX_SEASONS_PER_SERIES = 1
    private val MAX_SEASONS_DETAIL = 20

    suspend fun fetchSeriesRowsForHome(category: String? = null): List<HomePageRow> = withContext(Dispatchers.IO) {
        val url = buildSeriesListUrl(category, limit = 500)
        val allSeries = fetchSeriesList(url)
        val limitedSeries = allSeries.take(MAX_SERIES_FOR_HOME)
        val series = limitedSeries.mapNotNull { seriesItem ->
            processSeries(seriesItem, maxSeasons = MAX_SEASONS_PER_SERIES)
        }
        if (series.isEmpty()) return@withContext emptyList()
        val previews = series.map { MediaItemPreview.SeriesPreview(it.title, it.posterUrl, it.slug) }
        val displayName = when (category) {
            null -> "TV Series (Cineplex)"
            "Korean+Series" -> "Korean TV Series"
            "Indian+Series" -> "Indian TV Series"
            "Turkish+Series" -> "Turkish TV Series"
            "Bangla+Drama" -> "Bangla Drama"
            "Hindi+Series" -> "Hindi Series"
            "English+Series" -> "English Series"
            else -> "$category TV Series"
        }
        listOf(HomePageRow(displayName, previews))
    }

    suspend fun fetchAllSeriesByCategory(category: String? = null): List<Series> = withContext(Dispatchers.IO) {
        val url = buildSeriesListUrl(category, limit = 500)
        val seriesList = withTimeoutOrNull(15000L) {
            fetchSeriesList(url)
        } ?: return@withContext emptyList()
        seriesList.mapNotNull { seriesItem ->
            processSeries(seriesItem, maxSeasons = MAX_SEASONS_DETAIL)
        }
    }

    suspend fun fetchSeriesById(id: Int): Series? = withContext(Dispatchers.IO) {
        val allSeries = fetchSeriesList(buildSeriesListUrl(null, 500))
        val item = allSeries.find { it["id"] == id } ?: return@withContext null
        processSeries(item, maxSeasons = MAX_SEASONS_DETAIL)
    }

    private fun buildSeriesListUrl(category: String?, limit: Int): String {
        val catParam = if (category != null) "&category=${category.replace(" ", "+")}" else ""
        return "$seriesListBase?limit=$limit$catParam"
    }

    private suspend fun fetchSeriesList(url: String): List<Map<String, Any>> = withContext(Dispatchers.IO) {
        val body = fetchBody(url)
        val mapper = jacksonObjectMapper()
        try {
            mapper.readValue(body, object : TypeReference<List<Map<String, Any>>>() {})
        } catch (e: Exception) {
            try {
                val obj = mapper.readValue<Map<String, Any>>(body)
                (obj["data"] as? List<*>)?.filterIsInstance<Map<String, Any>>() ?: emptyList()
            } catch (e2: Exception) {
                emptyList()
            }
        }
    }

    private suspend fun processSeries(item: Map<String, Any>, maxSeasons: Int): Series? {
        val id = item["id"] as? Int ?: return null
        val title = item["title"] as? String ?: return null
        val year = (item["year"] as? String)?.toIntOrNull()
        var poster = item["poster"] as? String ?: ""
        if (poster.isNotEmpty() && !poster.startsWith("http")) poster = "$baseUrl$poster"
        val rating = item["imdb_rating"] as? String ?: ""

        val seasonsData = fetchSeasons(id, maxSeasons)
        if (seasonsData.isEmpty()) return null

        val seasons = seasonsData.map { (seasonNum, episodes, synopsis, _) ->
            val episodeList = episodes.map { ep ->
                val epNum = (ep["episode_number"] as? Int) ?: (ep["episodeNumber"] as? Int) ?: 0
                val epTitle = ep["title"] as? String ?: "Episode $epNum"
                var streamUrl = (ep["path"] as? String) ?: ""
                if (streamUrl.isNotEmpty()) streamUrl = normalizeUrl(streamUrl)
                var posterUrl = ep["still"] as? String ?: ""
                if (posterUrl.isNotEmpty() && !posterUrl.startsWith("http")) posterUrl = "$baseUrl$posterUrl"
                Episode(epTitle, epNum, streamUrl, null, posterUrl)
            }.sortedBy { it.episodeNumber }
            Season(seasonNum, episodeList)
        }.sortedBy { it.seasonNumber }

        val slug = "cine_series_$id"
        return Series(
            title = title,
            posterUrl = poster,
            backdropUrl = "",
            plot = seasonsData.firstOrNull()?.third ?: "",
            year = year,
            rating = rating.toDoubleOrNull(),
            genres = emptyList(),
            seasons = seasons,
            slug = slug
        )
    }

    private suspend fun fetchSeasons(seriesId: Int, maxSeasons: Int): List<Quad<Int, List<Map<String, Any>>, String, List<Map<String, Any>>>> {
        val seasons = mutableListOf<Quad<Int, List<Map<String, Any>>, String, List<Map<String, Any>>>>()
        var lastEpisodesHash = 0
        for (seasonNum in 1..maxSeasons) {
            val result = fetchSeasonEpisodes(seriesId, seasonNum)
            if (result == null) break
            val (_, episodes, _, _) = result
            if (episodes.isEmpty()) break
            val episodesHash = episodes.map { it["id"] }.hashCode()
            if (lastEpisodesHash != 0 && lastEpisodesHash == episodesHash) break
            lastEpisodesHash = episodesHash
            seasons.add(result)
        }
        if (seasons.isEmpty()) {
            val data = fetchBody("$seriesDetailUrl?id=$seriesId&meta=1")
            val mapper = jacksonObjectMapper()
            val obj = try { mapper.readValue<Map<String, Any>>(data) } catch (e: Exception) { null }
            if (obj != null) {
                val episodesRaw = obj["episodes"] as? Map<String, Any>
                if (episodesRaw != null) {
                    val episodesList = mutableListOf<Map<String, Any>>()
                    for ((_, epData) in episodesRaw) {
                        if (epData is Map<*, *>) {
                            @Suppress("UNCHECKED_CAST")
                            episodesList.add(epData as Map<String, Any>)
                        }
                    }
                    val synopsis = obj["synopsis"] as? String ?: ""
                    val cast = (obj["cast"] as? List<Map<String, Any>>) ?: emptyList()
                    if (episodesList.isNotEmpty()) {
                        return listOf(Quad(1, episodesList, synopsis, cast))
                    }
                }
            }
        }
        return seasons
    }

    private suspend fun fetchSeasonEpisodes(seriesId: Int, seasonNum: Int): Quad<Int, List<Map<String, Any>>, String, List<Map<String, Any>>>? {
        val url = "$seriesDetailUrl?id=$seriesId&meta=1&season=$seasonNum"
        val body = fetchBody(url)
        val mapper = jacksonObjectMapper()
        val data = try { mapper.readValue<Map<String, Any>>(body) } catch (e: Exception) { return null }
        val episodesRaw = data["episodes"] ?: return null
        val episodesList = mutableListOf<Map<String, Any>>()
        when (episodesRaw) {
            is Map<*, *> -> {
                for ((_, epData) in episodesRaw) {
                    if (epData is Map<*, *>) {
                        @Suppress("UNCHECKED_CAST")
                        val ep = epData as Map<String, Any>
                        val epNum = (ep["episode_number"] as? Int) ?: (ep["episodeNumber"] as? Int) ?: episodesList.size + 1
                        episodesList.add(ep.toMutableMap().apply { put("episode_number", epNum) })
                    }
                }
            }
            is List<*> -> {
                for (epData in episodesRaw) {
                    if (epData is Map<*, *>) {
                        @Suppress("UNCHECKED_CAST")
                        episodesList.add(epData as Map<String, Any>)
                    }
                }
            }
        }
        if (episodesList.isEmpty()) return null
        val synopsis = data["synopsis"] as? String ?: ""
        val cast = (data["cast"] as? List<Map<String, Any>>) ?: emptyList()
        return Quad(seasonNum, episodesList, synopsis, cast)
    }

    private suspend fun fetchBody(url: String): String = withContext(Dispatchers.IO) {
        val request = Request.Builder().url(url).apply {
            headers.forEach { (k, v) -> addHeader(k, v) }
        }.build()
        val response = client.newCall(request).execute()
        response.body?.string() ?: ""
    }

    private fun normalizeUrl(url: String): String {
        var clean = url.trim()
        if (clean.startsWith("//")) clean = "http:$clean"
        if (!clean.startsWith("http")) clean = "$baseUrl/$clean"
        clean = clean.replace('\\', '/')
        clean = clean.replace(" ", "%20")
        return clean
    }

    private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
}