package com.shimulfp.hub2stream.extractor.models

data class QualityInfo(
    val label: String,
    val url: String,
    val resolution: Int,
    val id: String  // stream ID for subtitle fetching
)