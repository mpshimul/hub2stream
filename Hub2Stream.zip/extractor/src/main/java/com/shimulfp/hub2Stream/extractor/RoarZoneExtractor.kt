package com.shimulfp.hub2stream.extractor

import com.shimulfp.hub2stream.extractor.models.LiveChannel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

class RoarZoneExtractor {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val baseUrl = "https://tv.roarzone.net/"
    private val playerBase = "https://tv.roarzone.net/player.php?stream="

    private val headers = mapOf(
        "User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept" to "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Language" to "en-US,en;q=0.5",
        "Referer" to baseUrl,
        "DNT" to "1",
        "Connection" to "keep-alive",
        "Upgrade-Insecure-Requests" to "1"
    )

    // Controls parallelism
    private val maxConcurrency = 10
    private val semaphore = java.util.concurrent.Semaphore(maxConcurrency)

    suspend fun fetchChannels(validateStreams: Boolean = true): List<LiveChannel> = withContext(Dispatchers.IO) {
        try {
            withTimeoutOrNull(120000L) {
                // Fetch main page with Jsoup
                val doc = Jsoup.connect(baseUrl)
                    .timeout(40000)
                    .headers(headers)
                    .get()
                val channelCards = doc.select("div.channel-card")
                println("RoarZoneExtractor: found ${channelCards.size} channel cards")

                // Collect raw data
                val rawChannels = channelCards.mapNotNull { card ->
                    val streamId = card.attr("data-stream")
                    if (streamId.isBlank()) return@mapNotNull null
                    val nameDiv = card.selectFirst("div.channel-info")
                    val name = nameDiv?.text()?.trim() ?: "Channel $streamId"
                    val category = card.attr("data-tags").ifBlank { "General" }
                    val logoImg = card.selectFirst("img")
                    val logo = if (logoImg != null) {
                        val src = logoImg.attr("src")
                        if (src.startsWith("http")) src else baseUrl + src
                    } else "https://tv.roarzone.net/favicon.ico"
                    RawChannel(streamId, name, category, logo)
                }

                println("RoarZoneExtractor: processing ${rawChannels.size} raw channels")

                // Process channels concurrently with limited parallelism
                val deferreds = rawChannels.map { raw ->
                    async {
                        semaphore.acquire()
                        try {
                            val playerUrl = playerBase + raw.id
                            val m3u8 = extractM3u8FromPlayer(playerUrl, raw.name)
                            if (m3u8 != null && (!validateStreams || isStreamReachable(m3u8))) {
                                LiveChannel(
                                    id = raw.id,
                                    name = raw.name,
                                    category = raw.category,
                                    logo = raw.logo,
                                    streamUrl = m3u8
                                )
                            } else null
                        } finally {
                            semaphore.release()
                        }
                    }
                }
                val channels = deferreds.awaitAll().filterNotNull()
                println("RoarZoneExtractor: returning ${channels.size} channels with stream URLs")
                channels
            } ?: emptyList()
        } catch (e: Exception) {
            println("RoarZoneExtractor error: ${e.message}")
            emptyList()
        }
    }

    private suspend fun extractM3u8FromPlayer(playerUrl: String, channelName: String): String? = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url(playerUrl)
                .headers(okhttp3.Headers.Builder().apply {
                    headers.forEach { (k, v) -> add(k, v) }
                }.build())
                .build()
            val response = client.newCall(request).execute()
            val html = response.body?.string() ?: return@withContext null
            // Patterns for m3u8
            val patterns = listOf(
                Regex("(https?://[^\\s\"']+\\.m3u8[^\\s\"']*)", RegexOption.IGNORE_CASE),
                Regex("src:\\s*[\"'](https?://[^\"']+\\.m3u8)[\"']", RegexOption.IGNORE_CASE),
                Regex("file:\\s*[\"'](https?://[^\"']+\\.m3u8)[\"']", RegexOption.IGNORE_CASE),
                Regex("url:\\s*[\"'](https?://[^\"']+\\.m3u8)[\"']", RegexOption.IGNORE_CASE),
                Regex("hlsUrl:\\s*[\"'](https?://[^\"']+\\.m3u8)[\"']", RegexOption.IGNORE_CASE)
            )
            for (pattern in patterns) {
                val match = pattern.find(html)
                if (match != null) {
                    var url = match.groupValues[1].trim().trim('"').trim('\'')
                    url = url.replace(Regex("\\);.*$"), "").replace(Regex("\\+.*$"), "")
                    return@withContext url
                }
            }
            null
        } catch (e: Exception) {
            null
        }
    }

    private fun isStreamReachable(url: String): Boolean {
        return try {
            val request = Request.Builder().url(url).head().build()
            val response = client.newCall(request).execute()
            response.isSuccessful
        } catch (e: Exception) {
            false
        }
    }

    private data class RawChannel(val id: String, val name: String, val category: String, val logo: String)
}