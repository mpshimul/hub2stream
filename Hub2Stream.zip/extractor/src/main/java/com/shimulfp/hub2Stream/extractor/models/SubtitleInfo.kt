package com.shimulfp.hub2stream.extractor.models

data class SubtitleInfo(
    val id: String,
    val languageCode: String,
    val languageName: String,
    val url: String
)