package com.shimulfp.hub2stream.extractor

import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.fasterxml.jackson.module.kotlin.readValue
import com.shimulfp.hub2stream.extractor.models.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Dns
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import java.net.InetAddress
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

class FmtpExtractor {
    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .callTimeout(30, TimeUnit.SECONDS)
            .protocols(listOf(Protocol.HTTP_2, Protocol.HTTP_1_1))
            .dns(object : Dns {
                private val cache = mutableMapOf<String, List<InetAddress>>()
                override fun lookup(hostname: String): List<InetAddress> {
                    return synchronized(cache) {
                        cache.getOrPut(hostname) {
                            try {
                                Dns.SYSTEM.lookup(hostname)
                            } catch (e: UnknownHostException) {
                                emptyList()
                            }
                        }
                    }
                }
            })
            .build()
    }

    private val baseUrl = "https://fmftp.net"
    private val apiMovies = "$baseUrl/api/movies"
    private val tmdbImageBase = "https://image.tmdb.org/t/p/w500"

    private val headers = mapOf(
        "User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept" to "application/json",
        "Accept-Language" to "en-US,en;q=0.9",
        "Referer" to "https://fmftp.net/",
        "Origin" to "https://fmftp.net"
    )

    suspend fun fetchMovieById(id: Int): Movie? {
        val url = "$apiMovies/$id"
        val json = getJson(url)
        return transformMovie(json)
    }

    suspend fun getHomePageRows(): List<HomePageRow> {
        val rows = mutableListOf<HomePageRow>()
        val limit = 500

        val bollywood = fetchMoviesByLibrary(1, limit)
        if (bollywood.isNotEmpty()) rows.add(HomePageRow("Bollywood Movies (FMTP)", bollywood))

        val hindiDubbed = fetchMoviesByLibrary(5, limit)
        if (hindiDubbed.isNotEmpty()) rows.add(HomePageRow("Hindi Dubbed Movies (FMTP)", hindiDubbed))

        val banglaMovies = fetchMoviesByLibrary(7, limit)
        if (banglaMovies.isNotEmpty()) rows.add(HomePageRow("Bangla Movies (FMTP)", banglaMovies))

        val latestMovies = fetchMoviesByLibrary(null, limit, sort = "release_date")
        if (latestMovies.isNotEmpty()) rows.add(HomePageRow("Latest Movies (FMTP)", latestMovies))

        return rows
    }

    private suspend fun fetchMoviesByLibrary(libraryId: Int?, limit: Int, sort: String = "release_date"): List<MediaItemPreview.MoviePreview> {
        val url = buildMoviesUrl(libraryId, limit, sort)
        val json = getJson(url)
        val data = json["data"] as? List<Map<String, Any>> ?: return emptyList()
        return data.mapNotNull { movie ->
            transformMovie(movie)?.let {
                MediaItemPreview.MoviePreview(it.title, it.posterUrl, it.slug)
            }
        }
    }

    private fun buildMoviesUrl(libraryId: Int?, limit: Int, sort: String): String {
        val base = "$apiMovies?limit=$limit&page=1&sort=$sort"
        return if (libraryId != null) "$base&library=$libraryId" else base
    }

    private fun transformMovie(item: Map<String, Any>): Movie? {
        val id = item["id"] as? Int ?: return null
        val title = item["title"] as? String ?: return null
        val year = (item["year"] as? String)?.toIntOrNull()
        val overview = item["overview"] as? String ?: ""
        val rating = (item["online_rating"] as? String)?.toDoubleOrNull()
        val posterPath = item["poster_path"] as? String ?: ""
        val backdropPath = item["backdrop_path"] as? String ?: ""
        val poster = if (posterPath.isNotEmpty()) "$tmdbImageBase$posterPath" else ""
        val backdrop = if (backdropPath.isNotEmpty()) "$tmdbImageBase$backdropPath" else ""
        val urlPath = item["url"] as? String ?: ""
        val streamUrl = if (urlPath.isNotEmpty()) "$baseUrl$urlPath" else ""
        val genreStr = item["genre"] as? String ?: ""
        val genres = genreStr.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        return Movie(
            title = title,
            streamUrl = streamUrl,
            posterUrl = poster,
            backdropUrl = backdrop,
            plot = overview,
            year = year,
            rating = rating,
            duration = null,
            director = "",
            genres = genres,
            slug = "fmtp_movie_$id"
        )
    }

    private suspend fun getJson(url: String): Map<String, Any> {
        val requestBuilder = Request.Builder().url(url)
        headers.forEach { (key, value) -> requestBuilder.addHeader(key, value) }
        val request = requestBuilder.build()
        val response = client.newCall(request).execute()
        val body = response.body?.string() ?: "{}"
        val clean = body.trim().replace(Regex("^[\\x00-\\x1F\\x7F]+"), "")
        return jacksonObjectMapper().readValue(clean)
    }
}