package com.shimulfp.hub2stream.extractor

import com.shimulfp.hub2stream.extractor.models.LiveChannel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.util.concurrent.TimeUnit
import java.util.zip.GZIPInputStream

class LiveTVExtractor {
    private val client = OkHttpClient.Builder()
        .connectTimeout(3, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private val baseUrl = "http://redforce.live/"
    private val streamBase = "http://redforce.live:8080/"
    private val streamPath = "hls/{}/index.m3u8"

    private val cookies = mapOf(
        "EFLIX" to "f5fg0i1gfa9kc38jvj1ee036uh",
        "REDFORCE" to "p42qghjj1tvq6gps4cglo7vdcn"
    )

    private val headers = mapOf(
        "User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept" to "text/html,application/xhtml+xml,application/xml;q=0.9",
        "Referer" to baseUrl,
        "Origin" to baseUrl.dropLast(1)
    )

    private var cachedChannels: List<LiveChannel>? = null
    private var cacheTimestamp = 0L
    private val CACHE_TTL = 30 * 60 * 1000 // 5 minutes

    suspend fun fetchChannels(forceRefresh: Boolean = false): List<LiveChannel> = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        if (!forceRefresh && cachedChannels != null && now - cacheTimestamp < CACHE_TTL) {
            return@withContext cachedChannels!!
        }
        try {
            val channels = withTimeoutOrNull(45000L) {
                val html = fetchHtmlWithDecompression(baseUrl)
                if (html.isBlank()) return@withTimeoutOrNull emptyList()
                val doc = Jsoup.parse(html)
                val lis = doc.select("li[class]")
                val rawChannels = mutableListOf<RawChannel>()
                for (li in lis) {
                    val aTag = li.selectFirst("a[onclick]") ?: continue
                    val onclick = aTag.attr("onclick")
                    val streamId = Regex("stream=(\\d+)").find(onclick)?.groupValues?.get(1) ?: continue
                    val imgTag = aTag.selectFirst("img") ?: continue
                    val logo = imgTag.attr("src").let { src ->
                        if (src.startsWith("http")) src else baseUrl + src
                    }
                    val name = imgTag.attr("alt").trim()
                    val category = li.className().split(" ").firstOrNull() ?: "All"
                    rawChannels.add(RawChannel(streamId, name, category, logo))
                }
                rawChannels.mapNotNull { raw ->
                    val streamUrl = resolveStreamUrlFast(raw.id, raw.name)
                    if (streamUrl != null) {
                        LiveChannel(raw.id, raw.name, raw.category, raw.logo, streamUrl)
                    } else null
                }
            } ?: emptyList()
            cachedChannels = channels
            cacheTimestamp = System.currentTimeMillis()
            channels
        } catch (e: Exception) { emptyList() }
    }

    suspend fun refreshChannelStreamUrl(channelId: String, channelName: String): String? = withContext(Dispatchers.IO) {
        resolveStreamUrlFast(channelId, channelName)
    }

    private suspend fun resolveStreamUrlFast(streamId: String, channelName: String): String? {
        val playerUrl = baseUrl + "player.php?stream=$streamId"
        val playerHtml = fetchHtmlWithDecompression(playerUrl)
        if (playerHtml.isBlank()) return null
        val patterns = listOf(
            Regex("[\"'](https?://[^\"']+\\.m3u8[^\"']*)[\"']"),
            Regex("src\\s*=\\s*[\"']([^\"']+\\.m3u8[^\"']*)[\"']"),
            Regex("file\\s*:\\s*[\"']([^\"']+\\.m3u8[^\"']*)[\"']")
        )
        for (pattern in patterns) {
            val match = pattern.find(playerHtml)
            if (match != null) {
                var url = match.groupValues[1].replace("\\", "").trim()
                if (url.startsWith("http")) {
                    return url.replace(" ", "%20")
                }
            }
        }
        // token fallback
        val tokenMatch = Regex("token=([a-f0-9-]{30,})").find(playerHtml)
            ?: Regex("[\"']token[\"']\\s*:\\s*[\"']([a-f0-9-]{30,})[\"']").find(playerHtml)
        if (tokenMatch != null) {
            val token = tokenMatch.groupValues[1]
            val cleanName = channelName.uppercase()
                .replace(Regex("[^\\w]"), ".")
                .replace(Regex("\\.+"), ".")
                .trim('.')
            val variations = listOf(cleanName, "$cleanName.HD", cleanName.replace(".", ""))
            for (variant in variations) {
                val path = streamPath.replace("{}", variant)
                return "$streamBase$path?token=$token&remote=no_check_ip"
            }
        }
        return null
    }

    private suspend fun fetchHtmlWithDecompression(url: String): String = withContext(Dispatchers.IO) {
        try {
            val requestBuilder = Request.Builder().url(url)
            headers.forEach { (k, v) -> requestBuilder.addHeader(k, v) }
            val cookieString = cookies.entries.joinToString("; ") { "${it.key}=${it.value}" }
            requestBuilder.addHeader("Cookie", cookieString)
            requestBuilder.addHeader("Accept-Encoding", "gzip, deflate")
            val response = client.newCall(requestBuilder.build()).execute()
            val bodyBytes = response.body?.bytes() ?: return@withContext ""
            val isGzipped = response.headers("Content-Encoding").any { it.contains("gzip") }
            if (isGzipped) {
                GZIPInputStream(bodyBytes.inputStream()).bufferedReader().use { it.readText() }
            } else {
                String(bodyBytes, Charsets.UTF_8)
            }
        } catch (e: Exception) { "" }
    }

    private data class RawChannel(val id: String, val name: String, val category: String, val logo: String)
}