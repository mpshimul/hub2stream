package com.shimulfp.hub2stream.extractor

import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.fasterxml.jackson.module.kotlin.readValue
import com.shimulfp.hub2stream.extractor.models.*
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class DhakaMovieExtractor {
    private val client = OkHttpClient.Builder()
        .connectTimeout(3, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)          // reduce read timeout as well
        .build()

    private val mapper = jacksonObjectMapper()
    private val mainUrl = "http://dhakamovie.com"
    private val apiMoviesBase = "http://dhakamovie.com:8080/api/movies"
    private val apiTvSeriesBase = "http://dhakamovie.com:8080/api/tv-series"
    private val advancedSearchBase = "http://dhakamovie.com:8080/api/advanced-search"

    private val headers = mapOf(
        "User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept" to "application/json",
        "Referer" to mainUrl
    )

    private val movieCache = mutableMapOf<String, Movie>()
    private val seriesCache = mutableMapOf<String, Series>()

    // Quick reachability test – single HEAD request
    private suspend fun isReachable(): Boolean {
        return try {
            val request = Request.Builder()
                .url(mainUrl)
                .head()
                .build()
            val response = client.newCall(request).execute()
            response.isSuccessful
        } catch (e: Exception) {
            false
        }
    }

    suspend fun getHomePageRows(): List<HomePageRow> {
        // First, test if the server is reachable at all
        if (!isReachable()) {
            println("DhakaMovie: server unreachable (single test), skipping all category requests")
            return emptyList()
        }

        return try {
            val rows = mutableListOf<HomePageRow>()

            // Latest all
            val latest = fetchMoviePreviews("$advancedSearchBase?query=&type=movies&page=1&per_page=5000&order_by=Latest")
            if (latest.isNotEmpty()) rows.add(HomePageRow("Latest Movies", latest))

            val trending = fetchMoviePreviews("$apiMoviesBase/trending")
            if (trending.isNotEmpty()) rows.add(HomePageRow("Trending", trending))

            val top10 = fetchMoviePreviews("$apiMoviesBase/top-10")
            if (top10.isNotEmpty()) rows.add(HomePageRow("Top 10 Movies", top10))

            // Bollywood
            val bollywood = fetchMoviePreviews("$advancedSearchBase?query=&type=movies&page=1&per_page=400&category=Bollywood&order_by=Latest")
            if (bollywood.isNotEmpty()) rows.add(HomePageRow("Bollywood Movies", bollywood))

            // South Indian
            val southIndian = fetchMoviePreviews("$advancedSearchBase?query=&type=movies&page=1&per_page=400&category=South+Indian&order_by=Latest")
            if (southIndian.isNotEmpty()) rows.add(HomePageRow("South Indian Movies", southIndian))

            // Hollywood
            val hollywood = fetchMoviePreviews("$advancedSearchBase?query=&type=movies&page=1&per_page=400&category=Hollywood&order_by=Latest")
            if (hollywood.isNotEmpty()) rows.add(HomePageRow("Hollywood Movies", hollywood))

            // Bangla
            val bangla = fetchMoviePreviews("$advancedSearchBase?query=&type=movies&page=1&per_page=4008&category=Indian+Bangla&order_by=Latest")
            if (bangla.isNotEmpty()) rows.add(HomePageRow("Bangla Movies", bangla))

            // Series all
            val series = fetchSeriesPreviews("$advancedSearchBase?type=tv_series&page=1&per_page=500&order_by=Latest")
            if (series.isNotEmpty()) rows.add(HomePageRow("TV Series", series))

            // Series Korean
            val seriesKorean = fetchSeriesPreviews("$advancedSearchBase?query=&type=tv_series&page=1&per_page=300&category=Korean&order_by=Latest")
            if (seriesKorean.isNotEmpty()) rows.add(HomePageRow("Korean TV Series", seriesKorean))

            rows
        } catch (e: Exception) {
            println("getHomePageRows error: ${e.message}")
            emptyList()
        }
    }
    private suspend fun fetchMoviePreviews(apiUrl: String): List<MediaItemPreview.MoviePreview> {
        println("fetchMoviePreviews: $apiUrl")
        return try {
            val json = getJson(apiUrl)
            println("fetchMoviePreviews: JSON keys = ${json.keys}")

            // Extract movies from the nested structure: results.movies.data
            val moviesList = when {
                // Case 1: Direct "data" array
                json.containsKey("data") && json["data"] is List<*> -> json["data"] as? List<Map<String, Any>>
                // Case 2: results.movies.data
                json.containsKey("results") -> {
                    val results = json["results"] as? Map<String, Any>
                    val moviesObj = results?.get("movies") as? Map<String, Any>
                    moviesObj?.get("data") as? List<Map<String, Any>> ?: emptyList()
                }
                else -> null
            } ?: emptyList()

            println("fetchMoviePreviews: movies size = ${moviesList.size}")
            moviesList.mapNotNull { movie ->
                val slug = movie["slug"] as? String ?: return@mapNotNull null
                val title = movie["title"] as? String ?: return@mapNotNull null
                var poster = movie["image"] as? String ?: movie["poster_url"] as? String ?: ""
                if (poster.isNotEmpty() && !poster.startsWith("http")) {
                    poster = if (poster.startsWith("/")) "$mainUrl:8080$poster" else "$mainUrl:8080/$poster"
                }
                val streamUrl = movie["stream_url"] as? String ?: ""
                val backdrop = (movie["backdrop_url"] as? String)?.let {
                    if (it.startsWith("/")) "$mainUrl:8080$it" else it
                } ?: poster
                val plot = movie["overview"] as? String ?: ""
                val year = (movie["year"] as? String)?.toIntOrNull()
                val rating = (movie["rating"] as? String)?.toDoubleOrNull()
                val genres = (movie["genres"] as? String)?.split(",")?.map { it.trim() } ?: emptyList()
                val movieObj = Movie(title, streamUrl, poster, backdrop, plot, year, rating, null, "", genres)
                movieCache["movie:$slug"] = movieObj
                MediaItemPreview.MoviePreview(title, poster, slug)
            }
        } catch (e: Exception) {
            println("fetchMoviePreviews error: ${e.message}")
            emptyList()
        }
    }
    private suspend fun fetchSeriesPreviews(apiUrl: String): List<MediaItemPreview.SeriesPreview> {
        return try {
            val json = getJson(apiUrl)
            val seriesList = when {
                json.containsKey("data") && json["data"] is List<*> -> json["data"] as? List<Map<String, Any>>
                json.containsKey("results") -> {
                    val results = json["results"] as? Map<String, Any>
                    val seriesObj = results?.get("series") as? Map<String, Any>
                    seriesObj?.get("data") as? List<Map<String, Any>>
                }
                else -> null
            } ?: emptyList()
            seriesList.mapNotNull { series ->
                val slug = series["slug"] as? String ?: return@mapNotNull null
                val title = series["title"] as? String ?: return@mapNotNull null
                var poster = series["poster_url"] as? String ?: series["image"] as? String ?: ""
                if (poster.isNotEmpty() && !poster.startsWith("http")) {
                    poster = if (poster.startsWith("/")) "$mainUrl:8080$poster" else "$mainUrl:8080/$poster"
                }
                MediaItemPreview.SeriesPreview(title, poster, slug)
            }
        } catch (e: Exception) {
            println("fetchSeriesPreviews error: ${e.message}")
            emptyList()
        }
    }

    // ------------------- Movie Details (with fallback) -------------------
    suspend fun loadMovieDetails(slug: String): Movie? {
        val key = "movie:$slug"
        // Check cache first
        movieCache[key]?.let { return it }
        println("loadMovieDetails: not in cache, trying direct fetch for slug: $slug")

        return try {
            // Try direct slug endpoint
            val url = "$apiMoviesBase/${URLEncoder.encode(slug, "UTF-8")}"
            println("Request URL: $url")
            val json = getJson(url)
            println("Response keys: ${json.keys}")

            // The API may return the movie inside a "data" field or directly
            val data = if (json.containsKey("data")) json["data"] as? Map<String, Any> else json
            if (data != null && data.containsKey("title")) {
                parseMovieFromMap(data).also { movieCache[key] = it }
            } else {
                // Fallback: search by title derived from slug
                val searchTitle = slug.replace("-", " ").replace("_", " ")
                println("Direct fetch failed, trying search for '$searchTitle'")
                val searchUrl = "$advancedSearchBase?type=movies&query=${URLEncoder.encode(searchTitle, "UTF-8")}&page=1"
                val searchJson = getJson(searchUrl)
                val results = searchJson["data"] as? List<Map<String, Any>> ?: emptyList()
                val matched = results.find { (it["slug"] as? String) == slug }
                if (matched != null) {
                    parseMovieFromMap(matched).also { movieCache[key] = it }
                } else {
                    println("Movie not found even after search for slug: $slug")
                    null
                }
            }
        } catch (e: Exception) {
            println("loadMovieDetails error: ${e.message}")
            e.printStackTrace()
            null
        }
    }

    private fun parseMovieFromMap(data: Map<String, Any>): Movie {
        val title = data["title"] as? String ?: "Unknown"
        var poster = data["poster_url"] as? String ?: ""
        if (poster.isNotEmpty() && !poster.startsWith("http")) {
            poster = if (poster.startsWith("/")) "$mainUrl:8080$poster" else "$mainUrl:8080/$poster"
        }
        val streamUrl = data["stream_url"] as? String ?: ""
        val backdrop = (data["backdrop_url"] as? String)?.let {
            if (it.startsWith("/")) "$mainUrl:8080$it" else it
        } ?: poster
        val plot = data["overview"] as? String ?: ""
        val year = (data["year"] as? String)?.toIntOrNull()
        val rating = (data["rating"] as? String)?.toDoubleOrNull()
        val genres = (data["genres"] as? String)?.split(",")?.map { it.trim() } ?: emptyList()
        return Movie(title, streamUrl, poster, backdrop, plot, year, rating, null, "", genres)
    }

    // ------------------- Series Details -------------------
    suspend fun loadSeriesDetails(slug: String): Series? {
        val key = "series:$slug"
        seriesCache[key]?.let { return it }
        return try {
            val url = "$apiTvSeriesBase/${URLEncoder.encode(slug, "UTF-8")}"
            val response = getJson(url)
            val data = response
            val title = data["title"] as? String ?: return null
            var poster = data["poster_url"] as? String ?: ""
            if (poster.isNotEmpty() && !poster.startsWith("http")) {
                poster = if (poster.startsWith("/")) "$mainUrl:8080$poster" else "$mainUrl:8080/$poster"
            }
            val plot = data["overview"] as? String ?: ""
            val year = (data["year"] as? String)?.toIntOrNull()
            val rating = (data["rating"] as? String)?.toDoubleOrNull()
            val genres = (data["genres"] as? String)?.split(",")?.map { it.trim() } ?: emptyList()
            val seasonsRaw = data["seasons"] as? List<Map<String, Any>> ?: emptyList()
            val seasons = seasonsRaw.mapNotNull { seasonMap ->
                val seasonNum = seasonMap["season_number"] as? Int ?: return@mapNotNull null
                val episodesRaw = seasonMap["episodes"] as? List<Map<String, Any>> ?: emptyList()
                val episodes = episodesRaw.mapNotNull { ep ->
                    val titleEp = ep["title"] as? String ?: "Episode ${ep["episode_number"]}"
                    val epNum = ep["episode_number"] as? Int ?: 1
                    val fileUrl = ep["file_url"] as? String ?: return@mapNotNull null
                    // --- FIX: remove extra "server1/" prefix ---
                    val cleanPath = fileUrl.removePrefix("server1/").trimStart('/')
                    val fullUrl = "http://server1.dhakamovie.com/$cleanPath".replace(" ", "%20")
                    // ------------------------------------------
                    val runtime = (ep["property"] as? Map<String, Any>)?.get("runtime") as? Int
                    var epPoster = ep["poster_url"] as? String ?: ""
                    if (epPoster.isNotEmpty() && !epPoster.startsWith("http")) {
                        epPoster = if (epPoster.startsWith("/")) "$mainUrl:8080$epPoster" else "$mainUrl:8080/$epPoster"
                    }
                    Episode(titleEp, epNum, fullUrl, runtime, epPoster)
                }
                Season(seasonNum, episodes)
            }
            val backdrop = (data["property"] as? Map<String, Any>)?.get("backdrop_path") as? String ?: ""
            val backdropUrl = if (backdrop.isNotEmpty() && !backdrop.startsWith("http")) {
                if (backdrop.startsWith("/")) "$mainUrl:8080$backdrop" else "$mainUrl:8080/$backdrop"
            } else ""
            val series = Series(title, poster, backdropUrl, plot, year, rating, genres, seasons)
            seriesCache[key] = series
            series
        } catch (e: Exception) { null }
    }

    // ------------------- Network helper -------------------
    private suspend fun getJson(url: String): Map<String, Any> {
        val headersBuilder = okhttp3.Headers.Builder()
        headers.forEach { (key, value) -> headersBuilder.add(key, value) }
        val request = Request.Builder().url(url).headers(headersBuilder.build()).build()
        val response = client.newCall(request).execute()
        val body = response.body?.string() ?: "{}"
        return mapper.readValue(body)
    }
}