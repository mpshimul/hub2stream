package com.shimulfp.hub2stream.extractor

import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.fasterxml.jackson.module.kotlin.readValue
import com.shimulfp.hub2stream.extractor.models.SportsEvent
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.UUID
import java.util.concurrent.TimeUnit

class SportsExtractor {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val jsonUrl = "https://raw.githubusercontent.com/drmlive/fancode-live-events/refs/heads/main/fancode.json"

    suspend fun fetchLiveEvents(): List<SportsEvent> = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        try {
            val json = getJson(jsonUrl)
            val matches = json["matches"] as? List<Map<String, Any>> ?: emptyList()
            val liveEvents = mutableListOf<SportsEvent>()
            for (match in matches) {
                if (match["status"] != "LIVE") continue
                val title = match["title"] as? String ?: "Unknown"
                val category = match["event_category"] as? String ?: "Sports"
                val tournament = match["event_name"] as? String ?: ""
                val logo = match["src"] as? String ?: ""
                val team1 = match["team_1"] as? String ?: ""
                val team2 = match["team_2"] as? String ?: ""
                val matchName = match["match_name"] as? String ?: title
                val originalUrl = (match["dai_url"] as? String) ?: (match["adfree_url"] as? String)
                if (originalUrl == null) continue
                val bdUrl = originalUrl.replace("in-mc", "bd-mc")
                liveEvents.add(
                    SportsEvent(
                        id = UUID.randomUUID().toString(),
                        name = "$matchName ($team1 vs $team2)",
                        category = category,
                        tournament = tournament,
                        team1 = team1,
                        team2 = team2,
                        logo = logo,
                        streamUrl = bdUrl,
                        fallbackUrl = originalUrl
                    )
                )
            }
            liveEvents
        } catch (e: Exception) { emptyList() }
    }

    private suspend fun getJson(url: String): Map<String, Any> = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val request = Request.Builder().url(url).build()
        val response = client.newCall(request).execute()
        val body = response.body?.string() ?: "{}"
        jacksonObjectMapper().readValue(body)
    }
}