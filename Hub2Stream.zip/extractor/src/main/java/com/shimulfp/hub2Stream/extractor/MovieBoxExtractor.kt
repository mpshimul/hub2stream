package com.shimulfp.hub2stream.extractor

import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.fasterxml.jackson.module.kotlin.readValue
import com.shimulfp.hub2stream.extractor.models.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Headers
import java.net.Proxy
import java.util.concurrent.TimeUnit
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody

class MovieBoxExtractor {
    private val apiBaseUrl = "https://h5-api.aoneroom.com/wefeed-h5api-bff"
    private val webBaseUrl = "https://themoviebox.org"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .proxy(Proxy.NO_PROXY)
        .build()

    private val mapper = jacksonObjectMapper()
    private var sessionCookies: String? = null
    private var cookieExpiry: Long = 0

    private suspend fun fetchCookies(): String {
        val request = Request.Builder()
            .url(webBaseUrl)
            .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
            .build()
        val response = client.newCall(request).execute()
        val cookies = response.headers("Set-Cookie").joinToString("; ") { it.substringBefore(";") }
        println("MovieBox: Fetched cookies: $cookies")
        return cookies
    }

    private suspend fun ensureCookies() {
        val now = System.currentTimeMillis()
        if (sessionCookies.isNullOrBlank() || now > cookieExpiry) {
            sessionCookies = fetchCookies()
            cookieExpiry = now + 24 * 60 * 60 * 1000L
        }
    }

    private suspend fun getJson(url: String, referer: String? = null, body: String? = null): Map<String, Any>? {
        return withContext(Dispatchers.IO) {
            try {
                ensureCookies()
                println("MovieBox: Requesting $url")
                val headersMap = mutableMapOf(
                    "User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                    "Accept" to "application/json, text/plain, */*",
                    "Cookie" to sessionCookies!!
                )
                referer?.let { headersMap["Referer"] = it }
                if (body != null) {
                    headersMap["Content-Type"] = "application/json; charset=utf-8"
                }

                val headersBuilder = Headers.Builder()
                headersMap.forEach { (k, v) -> headersBuilder.add(k, v) }
                val requestBuilder = Request.Builder()
                    .url(url)
                    .headers(headersBuilder.build())
                if (body != null) {
                    requestBuilder.post(body.toRequestBody("application/json; charset=utf-8".toMediaType()))
                } else {
                    requestBuilder.get()
                }
                val response = client.newCall(requestBuilder.build()).execute()
                println("MovieBox: Response code ${response.code}")
                val responseBody = response.body?.string() ?: "{}"
                println("MovieBox: Response body: ${responseBody.take(500)}")
                if (!response.isSuccessful) return@withContext null
                mapper.readValue(responseBody)
            } catch (e: Exception) {
                println("MovieBox: Network error: ${e.message}")
                e.printStackTrace()
                null
            }
        }
    }

    // ------------------------------------------------------------------
    // Home page & category endpoints
    // ------------------------------------------------------------------
    suspend fun getHomePageRows(): List<HomePageRow> = withContext(Dispatchers.IO) {
        val categories = mapOf(
            "414907768299210008" to "Bollywood",
            "3859721901924910512" to "South Indian",
            "8019599703232971616" to "Hollywood",
            "4741626294545400336" to "Top Series This Week",
            "7878715743607948784" to "Korean Drama"
        )
        val rows = mutableListOf<HomePageRow>()
        for ((catId, title) in categories) {
            val items = fetchCategoryItems(catId)
            if (items.isNotEmpty()) rows.add(HomePageRow(title, items))
        }
        rows
    }

    private suspend fun fetchCategoryItems(categoryId: String): List<MediaItemPreview> {
        val url = "$apiBaseUrl/ranking-list/content?id=$categoryId&page=1&perPage=15"
        val json = getJson(url) ?: return emptyList()
        val data = json["data"] as? Map<String, Any>
        val list = data?.get("subjectList") as? List<Map<String, Any>> ?: return emptyList()
        return list.mapNotNull { item ->
            val id = item["subjectId"]?.toString() ?: return@mapNotNull null
            val title = item["title"] as? String ?: return@mapNotNull null
            val coverObj = item["cover"] as? Map<String, Any>
            val cover = coverObj?.get("url") as? String ?: ""
            val type = (item["subjectType"] as? Number)?.toInt() ?: 1
            val detailPath = item["detailPath"] as? String ?: id
            if (type == 1) MediaItemPreview.MoviePreview(title, cover, detailPath)
            else MediaItemPreview.SeriesPreview(title, cover, detailPath)
        }
    }

    suspend fun getAllSeriesByCategory(categoryName: String?): List<Series> = withContext(Dispatchers.IO) {
        val categoryId = when (categoryName) {
            "Korean+Series" -> "7878715743607948784"
            "Indian+Series" -> "5177200225164885656"
            "Turkish+Series" -> "3910636007619709856"
            "Hindi+Series" -> "4741626294545400336"
            "English+Series" -> "8019599703232971616"
            else -> null
        }
        if (categoryId == null) return@withContext emptyList()
        val url = "$apiBaseUrl/ranking-list/content?id=$categoryId&page=1&perPage=50"
        val json = getJson(url) ?: return@withContext emptyList()
        val data = json["data"] as? Map<String, Any>
        val list = data?.get("subjectList") as? List<Map<String, Any>> ?: return@withContext emptyList()
        list.mapNotNull { item ->
            val detailPath = item["detailPath"] as? String ?: return@mapNotNull null
            getSeriesDetails(detailPath)
        }
    }

    // ------------------------------------------------------------------
    // Details (movie & series)
    // ------------------------------------------------------------------
    suspend fun getMovieDetails(detailPath: String): Movie? = withContext(Dispatchers.IO) {
        val url = "$apiBaseUrl/detail?detailPath=$detailPath"
        val json = getJson(url) ?: return@withContext null
        val data = json["data"] as? Map<String, Any>
        val subject = data?.get("subject") as? Map<String, Any> ?: return@withContext null
        val title = subject["title"] as? String ?: return@withContext null
        val description = subject["description"] as? String ?: ""
        val releaseDate = subject["releaseDate"] as? String ?: ""
        val year = releaseDate.take(4).toIntOrNull()
        val rating = (subject["imdbRatingValue"] as? String)?.toDoubleOrNull()
        val cover = (subject["cover"] as? Map<String, Any>)?.get("url") as? String ?: ""
        val genre = subject["genre"] as? String ?: ""
        val genres = genre.split(",").map { it.trim() }
        val subjectId = subject["subjectId"]?.toString() ?: ""
        val streamUrl = "moviebox://$subjectId|||$detailPath"
        Movie(title, streamUrl, cover, cover, description, year, rating, null, "", genres, detailPath)
    }

    suspend fun getSeriesDetails(detailPath: String): Series? = withContext(Dispatchers.IO) {
        val url = "$apiBaseUrl/detail?detailPath=$detailPath"
        val json = getJson(url) ?: return@withContext null
        val data = json["data"] as? Map<String, Any>
        val subject = data?.get("subject") as? Map<String, Any> ?: return@withContext null
        val title = subject["title"] as? String ?: return@withContext null
        val description = subject["description"] as? String ?: ""
        val releaseDate = subject["releaseDate"] as? String ?: ""
        val year = releaseDate.take(4).toIntOrNull()
        val rating = (subject["imdbRatingValue"] as? String)?.toDoubleOrNull()
        val cover = (subject["cover"] as? Map<String, Any>)?.get("url") as? String ?: ""
        val genre = subject["genre"] as? String ?: ""
        val genres = genre.split(",").map { it.trim() }
        val subjectId = subject["subjectId"]?.toString() ?: ""
        val resource = data["resource"] as? Map<String, Any>
        val seasonsArray = resource?.get("seasons") as? List<Map<String, Any>>
        val seasons = if (!seasonsArray.isNullOrEmpty()) {
            seasonsArray.mapNotNull { seasonMap ->
                val seasonNumber = (seasonMap["se"] as? Number)?.toInt() ?: return@mapNotNull null
                val maxEp = (seasonMap["maxEp"] as? Number)?.toInt() ?: 0
                val episodes = (1..maxEp).map { epNum ->
                    Episode(
                        title = "Episode $epNum",
                        episodeNumber = epNum,
                        filePath = "moviebox://$subjectId|$seasonNumber|$epNum|$detailPath",
                        runtime = null,
                        posterUrl = ""
                    )
                }
                Season(seasonNumber, episodes)
            }
        } else emptyList()
        Series(title, cover, cover, description, year, rating, genres, seasons, detailPath)
    }

    suspend fun loadLinks(linkData: String, callback: (String, String, String?) -> Unit) {
        val parts = linkData.split("|")
        val subjectId = parts.getOrNull(0) ?: ""
        val season = parts.getOrNull(1)?.toIntOrNull() ?: 0
        val episode = parts.getOrNull(2)?.toIntOrNull() ?: 0
        val detailPath = parts.getOrNull(3)
        val url = "$apiBaseUrl/subject/download?subjectId=$subjectId&se=$season&ep=$episode"
        val referer = "$webBaseUrl/movies/$detailPath"
        val json = getJson(url, referer) ?: run { callback("", "MovieBox", null); return }
        val data = json["data"] as? Map<String, Any>
        val downloads = data?.get("downloads") as? List<Map<String, Any>> ?: run { callback("", "MovieBox", null); return }
        val best = downloads.maxByOrNull { (it["resolution"] as? Number)?.toInt() ?: 0 }
        val streamUrl = best?.get("url") as? String
        callback(streamUrl ?: "", "MovieBox", null)
    }

    // ------------------------------------------------------------------
    // Get stream qualities (includes id for subtitles)
    // ------------------------------------------------------------------
    suspend fun getStreams(linkData: String, callback: (List<QualityInfo>, String?) -> Unit) {
        val parts = linkData.split("|")
        val subjectId = parts.getOrNull(0) ?: ""
        val season = parts.getOrNull(1)?.toIntOrNull() ?: 0
        val episode = parts.getOrNull(2)?.toIntOrNull() ?: 0
        val detailPath = parts.getOrNull(3)

        val url = "$apiBaseUrl/subject/download?subjectId=$subjectId&se=$season&ep=$episode"
        val referer = "$webBaseUrl/movies/$detailPath"
        val json = getJson(url, referer) ?: run { callback(emptyList(), null); return }
        val data = json["data"] as? Map<String, Any>
        val downloads = data?.get("downloads") as? List<Map<String, Any>> ?: run { callback(emptyList(), null); return }
        val qualities = downloads.mapNotNull {
            val resolution = it["resolution"] as? Int ?: 0
            val url = it["url"] as? String ?: return@mapNotNull null
            val id = it["id"] as? String ?: ""
            val label = when {
                resolution >= 2160 -> "4K"
                resolution >= 1080 -> "1080p"
                resolution >= 720 -> "720p"
                resolution >= 480 -> "480p"
                else -> "${resolution}p"
            }
            QualityInfo(label, url, resolution, id)
        }
        callback(qualities, null)
    }

    // ------------------------------------------------------------------
    // Fetch subtitles for a specific stream
    // ------------------------------------------------------------------
    suspend fun fetchSubtitles(
        subjectId: String,
        resourceId: String,
        detailPath: String,
        format: String = "MP4"
    ): List<SubtitleInfo> {
        val url = "$apiBaseUrl/subject/caption?format=$format&id=$resourceId&subjectId=$subjectId&detailPath=$detailPath"
        val referer = "$webBaseUrl/movies/$detailPath"
        val json = getJson(url, referer) ?: return emptyList()
        val data = json["data"] as? Map<String, Any>
        val captionsList = data?.get("captions") as? List<Map<String, Any>> ?: return emptyList()
        return captionsList.mapNotNull {
            val id = it["id"] as? String ?: return@mapNotNull null
            val lan = it["lan"] as? String ?: return@mapNotNull null
            val lanName = it["lanName"] as? String ?: lan
            val subUrl = it["url"] as? String ?: return@mapNotNull null
            SubtitleInfo(id, lan, lanName, subUrl)
        }
    }

    suspend fun search(query: String, page: Int = 1): List<MediaItemPreview> {
        val url = "$apiBaseUrl/subject-api/search/v2"
        val body = """{"page":$page,"perPage":20,"keyword":"$query"}"""
        val referer = webBaseUrl
        val json = getJson(url, referer, body) ?: return emptyList()
        val data = json["data"] as? Map<String, Any>
        val results = data?.get("results") as? List<Map<String, Any>> ?: return emptyList()
        val items = mutableListOf<MediaItemPreview>()
        for (result in results) {
            val subjects = result["subjects"] as? List<Map<String, Any>> ?: continue
            for (subject in subjects) {
                val id = subject["subjectId"] as? String ?: continue
                val title = subject["title"] as? String ?: continue
                val coverObj = subject["cover"] as? Map<String, Any>
                val cover = coverObj?.get("url") as? String ?: ""
                val subjectType = subject["subjectType"] as? Int ?: 1
                val detailPath = subject["detailPath"] as? String ?: id
                if (subjectType == 1) {
                    items.add(MediaItemPreview.MoviePreview(title, cover, detailPath))
                } else {
                    items.add(MediaItemPreview.SeriesPreview(title, cover, detailPath))
                }
            }
        }
        return items
    }
}