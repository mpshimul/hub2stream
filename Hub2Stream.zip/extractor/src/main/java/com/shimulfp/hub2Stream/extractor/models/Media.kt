package com.shimulfp.hub2stream.extractor.models

import com.fasterxml.jackson.annotation.JsonSubTypes
import com.fasterxml.jackson.annotation.JsonTypeInfo

@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "type")
@JsonSubTypes(
    JsonSubTypes.Type(value = MediaItemPreview.MoviePreview::class, name = "movie"),
    JsonSubTypes.Type(value = MediaItemPreview.SeriesPreview::class, name = "series")
)
sealed class MediaItemPreview {
    abstract val title: String
    abstract val posterUrl: String
    abstract val slug: String

    data class MoviePreview(
        override val title: String,
        override val posterUrl: String,
        override val slug: String
    ) : MediaItemPreview()

    data class SeriesPreview(
        override val title: String,
        override val posterUrl: String,
        override val slug: String
    ) : MediaItemPreview()
}

data class HomePageRow(
    val title: String,
    val items: List<MediaItemPreview>
)

data class Movie(
    val title: String,
    val streamUrl: String,
    val posterUrl: String,
    val backdropUrl: String,
    val plot: String,
    val year: Int?,
    val rating: Double?,
    val duration: Int?,
    val director: String,
    val genres: List<String>,
    val slug: String = ""   // added
)

data class Episode(
    val title: String,
    val episodeNumber: Int,
    val filePath: String,
    val runtime: Int?,
    val posterUrl: String
)

data class Season(
    val seasonNumber: Int,
    val episodes: List<Episode>
)

data class Series(
    val title: String,
    val posterUrl: String,
    val backdropUrl: String,
    val plot: String,
    val year: Int?,
    val rating: Double?,
    val genres: List<String>,
    val seasons: List<Season>,
    val slug: String = ""   // added
)

data class LiveChannel(
    val id: String,
    val name: String,
    val category: String,
    val logo: String,
    val streamUrl: String
)

data class SportsEvent(
    val id: String,
    val name: String,
    val category: String,
    val tournament: String,
    val team1: String,
    val team2: String,
    val logo: String,
    val streamUrl: String,
    val fallbackUrl: String? = null
)